import { useState } from "react";

export function useSimulation() {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speed, setSpeed] = useState<1 | 2 | 5 | 10>(1);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(38538); // 10:42:18 in seconds from midnight

  const togglePlay = () => setIsPlaying(!isPlaying);

  const changeSpeed = (newSpeed: 1 | 2 | 5 | 10) => {
    setSpeed(newSpeed);
  };

  const seekTime = (seconds: number) => {
    setCurrentTimeSec(seconds);
  };

  return {
    isPlaying,
    togglePlay,
    speed,
    changeSpeed,
    currentTimeSec,
    seekTime
  };
}
