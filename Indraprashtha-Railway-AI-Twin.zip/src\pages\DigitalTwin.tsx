import React from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { DigitalTwinMap } from "../components/railway/DigitalTwinMap";
import { DetailDrawer } from "../components/railway/DetailDrawer";
import { Network } from "lucide-react";

interface DigitalTwinProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const {
    trains,
    blocks,
    signals,
    stations,
    conflicts,
    selectedItem,
    setSelectedItem,
    isDemoModeActive,
    setIsDemoModeActive,
    currentDemoStepIndex,
    selectTrain,
    selectBlock,
    selectSignal,
    selectStation,
    resetState
  } = railwayState;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-hidden">
          <div className="flex items-center justify-between p-3 rounded bg-slate-900 border border-slate-800 font-mono text-xs">
            <div className="flex items-center space-x-3">
              <Network className="w-5 h-5 text-cyan-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">RAILWAY DIGITAL TWIN — FULL CORRIDOR SCHEMATIC</h2>
                <p className="text-slate-400">Delhi Junction (km 0.0) to Sonipat Junction (km 44.0) • Double Track + Loop Sidings</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 text-xs">
              <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500 scada-pulse" />
                <span>REAL-TIME POSITIONS SYNCED</span>
              </div>
              <div className="px-2.5 py-1 rounded bg-slate-800 text-slate-300">
                25 BLOCKS • 12 SIGNALS • 8 STATIONS
              </div>
            </div>
          </div>

          <div className="flex-1 relative">
            <DigitalTwinMap
              trains={trains}
              blocks={blocks}
              signals={signals}
              stations={stations}
              onSelectTrain={selectTrain}
              onSelectBlock={selectBlock}
              onSelectSignal={selectSignal}
              onSelectStation={selectStation}
              selectedId={selectedItem?.id}
            />
          </div>
        </div>
      </div>

      <DetailDrawer selectedItem={selectedItem} onClose={() => setSelectedItem(null)} />
    </div>
  );
};
