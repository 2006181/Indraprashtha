import type { Block, Train } from "../types/railway";

export const calculateTrainCoordinates = (
  train: Train,
  blocks: Block[]
): { x: number; y: number } => {
  const currentBlockObj = blocks.find((b) => b.id === train.currentBlock);
  if (!currentBlockObj) {
    return { x: 100, y: 190 };
  }

  // Calculate position along start -> end of block based on progress
  const progressRatio = (train.routeProgress % 100) / 100;
  const start = currentBlockObj.startCoord;
  const end = currentBlockObj.endCoord;

  const x = start.x + (end.x - start.x) * progressRatio;
  const y = start.y + (end.y - start.y) * progressRatio;

  return { x, y };
};

export const checkHeadwaySafety = (
  train1: Train,
  train2: Train,
  minHeadwaySeconds: number = 180
): { isSafe: boolean; marginSeconds: number } => {
  const speedAvgKmH = (train1.speed + train2.speed) / 2 || 60;
  const distanceKm = Math.abs(train1.routeProgress - train2.routeProgress) * 0.44; // 44km total corridor
  const timeDiffSeconds = (distanceKm / speedAvgKmH) * 3600;

  return {
    isSafe: timeDiffSeconds >= minHeadwaySeconds,
    marginSeconds: Math.round(timeDiffSeconds)
  };
};

export const computeSectionThroughput = (
  activeTrains: number,
  avgSpeedKmH: number,
  headwayMinutes: number = 3.5
): number => {
  if (activeTrains === 0) return 0;
  const theoreticalMax = 60 / headwayMinutes;
  const utilizationFactor = Math.min(1.0, (avgSpeedKmH / 100) * 0.9);
  return Number((theoreticalMax * utilizationFactor).toFixed(1));
};
