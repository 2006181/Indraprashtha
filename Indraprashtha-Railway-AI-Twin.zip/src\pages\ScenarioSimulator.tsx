import React, { useState } from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { DigitalTwinMap } from "../components/railway/DigitalTwinMap";
import { DetailDrawer } from "../components/railway/DetailDrawer";
import { WHAT_IF_SCENARIOS } from "../data/scenarios";
import { FlaskConical, Play, Pause, Zap } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

interface ScenarioSimulatorProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const ScenarioSimulator: React.FC<ScenarioSimulatorProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const {
    trains,
    blocks,
    signals,
    stations,
    conflicts,
    selectedItem,
    setSelectedItem,
    isDemoModeActive,
    setIsDemoModeActive,
    currentDemoStepIndex,
    selectTrain,
    selectBlock,
    selectSignal,
    selectStation,
    isPlaying,
    setIsPlaying,
    speedMultiplier,
    setSpeedMultiplier,
    resetState
  } = railwayState;

  const [selectedScenarioId, setSelectedScenarioId] = useState<string>("SCN_01");
  const [injectedTrainId, setInjectedTrainId] = useState<string>("F21");
  const [injectedDelayMinutes, setInjectedDelayMinutes] = useState<number>(15);
  const [trafficLevel, setTrafficLevel] = useState<string>("HIGH");

  const currentScenario = WHAT_IF_SCENARIOS.find((s) => s.id === selectedScenarioId) || WHAT_IF_SCENARIOS[0];

  // Dynamically calculate strategy metrics based on injected delay slider
  const dynamicStrategies = currentScenario.strategies.map((strat) => {
    const delayFactor = strat.id.includes("STRAT_A") ? 0.82 : strat.id.includes("STRAT_B") ? 0.47 : 0.34;
    const computedDelay = Number((injectedDelayMinutes * delayFactor).toFixed(1));
    const computedThroughput = Number((10 - computedDelay * 0.3).toFixed(1));

    return {
      ...strat,
      avgDelayMinutes: computedDelay,
      throughputPerHour: Math.max(6.0, computedThroughput)
    };
  });

  const chartData = dynamicStrategies.map((strat) => ({
    name: strat.name.split(":")[0],
    avgDelay: strat.avgDelayMinutes,
    throughput: strat.throughputPerHour
  }));

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-3 space-y-3 overflow-hidden font-mono text-xs select-none">
          <div className="flex items-center justify-between p-3 rounded bg-slate-900 border border-slate-800">
            <div className="flex items-center space-x-3">
              <FlaskConical className="w-5 h-5 text-purple-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">WHAT-IF SCENARIO SIMULATOR</h2>
                <p className="text-slate-400">Test operational dispatch decisions in simulation environment before applying live</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded border border-slate-800">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`flex items-center space-x-1.5 px-3 py-1 rounded font-bold ${
                  isPlaying ? "bg-amber-950 text-amber-300 border border-amber-800" : "bg-emerald-950 text-emerald-300 border border-emerald-800"
                }`}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlaying ? "PAUSE SIM" : "RUN SIM"}</span>
              </button>

              <div className="flex items-center space-x-1 border-l border-slate-800 pl-2">
                {[1, 2, 5, 10].map((s) => (
                  <button
                    key={s}
                    onClick={() => setSpeedMultiplier(s)}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      speedMultiplier === s ? "bg-purple-950 text-purple-300 border border-purple-700" : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {s}×
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex-1 grid grid-cols-12 gap-3 overflow-hidden">
            <div className="col-span-3 bg-slate-950 border border-slate-800 rounded p-3 flex flex-col space-y-3 overflow-y-auto">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-slate-800 pb-1">
                CREATE SCENARIO
              </h3>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase">PRESET SCENARIO</label>
                <select
                  value={selectedScenarioId}
                  onChange={(e) => setSelectedScenarioId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200"
                >
                  {WHAT_IF_SCENARIOS.map((s) => (
                    <option key={s.id} value={s.id}>{s.title}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase">TARGET TRAIN DELAY</label>
                <select
                  value={injectedTrainId}
                  onChange={(e) => setInjectedTrainId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200"
                >
                  {trains.map((t) => (
                    <option key={t.id} value={t.id}>{t.id} - {t.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <label className="text-[10px] text-slate-400 uppercase">INJECTED DELAY</label>
                  <span className="text-amber-400 font-bold">+{injectedDelayMinutes} min</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="30"
                  value={injectedDelayMinutes}
                  onChange={(e) => setInjectedDelayMinutes(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase">TRAFFIC DENSITY</label>
                <div className="grid grid-cols-3 gap-1">
                  {["NORMAL", "HIGH", "PEAK"].map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setTrafficLevel(lvl)}
                      className={`py-1 rounded text-[10px] font-bold ${
                        trafficLevel === lvl ? "bg-purple-950 text-purple-300 border border-purple-700" : "bg-slate-900 text-slate-400 border border-slate-800"
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setIsPlaying(true)}
                className="w-full py-2.5 rounded bg-purple-600 hover:bg-purple-500 text-white font-bold tracking-wide transition-colors flex items-center justify-center space-x-1.5 shadow-lg mt-auto"
              >
                <Zap className="w-4 h-4" />
                <span>RUN SIMULATION</span>
              </button>
            </div>

            <div className="col-span-5 relative h-full">
              <DigitalTwinMap
                trains={trains}
                blocks={blocks}
                signals={signals}
                stations={stations}
                conflicts={conflicts}
                onSelectTrain={selectTrain}
                onSelectBlock={selectBlock}
                onSelectSignal={selectSignal}
                onSelectStation={selectStation}
                selectedId={selectedItem?.id}
                highlightTrainId={injectedTrainId}
              />
            </div>

            <div className="col-span-4 bg-slate-950 border border-slate-800 rounded p-3 flex flex-col space-y-3 overflow-y-auto">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-slate-800 pb-1">
                STRATEGY COMPARISON
              </h3>

              <div className="space-y-2">
                {dynamicStrategies.map((strat) => (
                  <div
                    key={strat.id}
                    className={`p-3 rounded border transition-all ${
                      strat.isAiRecommended
                        ? "bg-gradient-to-r from-cyan-950/60 to-slate-900 border-cyan-500/80 ring-1 ring-cyan-500/40"
                        : "bg-slate-900/80 border-slate-800"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-100">{strat.name}</span>
                      {strat.isAiRecommended && (
                        <span className="px-2 py-0.5 rounded bg-cyan-900 text-cyan-200 text-[10px] font-bold">
                          AI RECOMMENDED ★
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{strat.description}</p>

                    <div className="grid grid-cols-3 gap-2 mt-2 font-mono text-[10px]">
                      <div className="bg-slate-950 p-1.5 rounded border border-slate-800 text-center">
                        <span className="text-slate-500 block">Delay</span>
                        <span className="font-bold text-emerald-400">{strat.avgDelayMinutes}m</span>
                      </div>
                      <div className="bg-slate-950 p-1.5 rounded border border-slate-800 text-center">
                        <span className="text-slate-500 block">Throughput</span>
                        <span className="font-bold text-cyan-400">{strat.throughputPerHour}/h</span>
                      </div>
                      <div className="bg-slate-950 p-1.5 rounded border border-slate-800 text-center">
                        <span className="text-slate-500 block">Risk</span>
                        <span className={`font-bold ${strat.riskLevel === "LOW" ? "text-emerald-400" : "text-amber-400"}`}>{strat.riskLevel}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase">DELAY & THROUGHPUT METRICS</span>
                <div className="h-36 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={10} />
                      <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155" }} />
                      <Bar dataKey="avgDelay" fill="#f43f5e" name="Avg Delay (min)" />
                      <Bar dataKey="throughput" fill="#10b981" name="Throughput (t/h)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <DetailDrawer selectedItem={selectedItem} onClose={() => setSelectedItem(null)} />
    </div>
  );
};
