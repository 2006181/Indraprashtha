import type { MetricSummary, SubsystemHealth } from "../types/railway";

export const INITIAL_METRICS: MetricSummary = {
  throughputPerHour: 9.2,
  throughputTrendPercent: 12.4,
  avgDelayMinutes: 4.3,
  delayTrendPercent: -18.7,
  activeTrainsCount: 18,
  activeConflictsCount: 0,
  sectionUtilizationPercent: 78.4,
  safetyScore: 99.8
};

export const SUBSYSTEM_HEALTH: SubsystemHealth = {
  digitalTwin: "HEALTHY",
  simulationEngine: "HEALTHY",
  mlEngine: "HEALTHY",
  optimizationEngine: "HEALTHY",
  safetyEngine: "HEALTHY",
  tickRatePerSec: 24,
  latencyMs: 84,
  optimizationTimeSec: 0.82,
  activeWebSocketCount: 1,
  dataFreshnessSec: 1.2
};

export const MODEL_EVALUATIONS = [
  {
    modelName: "ETA Prediction (XGBoost + Transformer)",
    status: "ACTIVE",
    mae: "1.82 min",
    rmse: "2.41 min",
    confidence: "93.1%",
    lastTrained: "2026-08-15 04:00",
    features: ["Block Occupancy", "Speed Gradient", "Historical Delay", "Weather"]
  },
  {
    modelName: "Delay Propagation Engine (GNN Graph Model)",
    status: "ACTIVE",
    mae: "2.14 min",
    rmse: "2.89 min",
    confidence: "89.7%",
    lastTrained: "2026-08-15 04:00",
    features: ["Section Topology", "Train Headway", "Priority Weights", "Loop Availability"]
  },
  {
    modelName: "Conflict Prediction (Deep Spatio-Temporal)",
    status: "ACTIVE",
    mae: "0.94 F1",
    rmse: "0.04 Loss",
    confidence: "95.2%",
    lastTrained: "2026-08-15 04:00",
    features: ["Path Trajectory", "Speed Curves", "Signal State Sequence", "Safety Margin"]
  }
];

export const THROUGHPUT_TREND_DATA = [
  { time: "06:00", baseline: 6.8, aiOptimized: 7.2 },
  { time: "07:00", baseline: 7.5, aiOptimized: 8.4 },
  { time: "08:00", baseline: 8.1, aiOptimized: 9.1 },
  { time: "09:00", baseline: 7.9, aiOptimized: 9.3 },
  { time: "10:00", baseline: 8.2, aiOptimized: 9.2 },
  { time: "11:00", baseline: 7.4, aiOptimized: 8.9 },
  { time: "12:00", baseline: 8.0, aiOptimized: 9.5 }
];

export const DELAY_DISTRIBUTION_DATA = [
  { range: "On Time (<2m)", count: 11, percent: 55 },
  { range: "Minor (2-5m)", count: 5, percent: 25 },
  { range: "Moderate (5-10m)", count: 3, percent: 15 },
  { range: "Severe (>10m)", count: 1, percent: 5 }
];

export const BLOCK_UTILIZATION_DATA = [
  { block: "B01", utilization: 88, name: "Delhi Yard" },
  { block: "B03", utilization: 55, name: "Subzi Mandi" },
  { block: "B05", utilization: 92, name: "Azadpur" },
  { block: "B07", utilization: 96, name: "Adarsh Nagar" },
  { block: "B08", utilization: 84, name: "Adarsh-Badli" },
  { block: "B10", utilization: 72, name: "Badli-Holambi" },
  { block: "B14", utilization: 77, name: "Narela-Sonipat" },
  { block: "B20", utilization: 81, name: "Holambi South" }
];

export const TRAIN_TYPE_DISTRIBUTION = [
  { name: "Express", value: 4, color: "#0284C7" },
  { name: "Passenger", value: 3, color: "#10B981" },
  { name: "Freight", value: 4, color: "#F59E0B" },
  { name: "Maintenance", value: 1, color: "#A855F7" }
];

export const COMPARISON_METRICS = [
  { category: "Avg Delay (min)", baseline: 8.4, aiOptimized: 5.1, improvement: "-39.2%" },
  { category: "Throughput (trains/hr)", baseline: 8.1, aiOptimized: 9.4, improvement: "+16.0%" },
  { category: "Section Utilization (%)", baseline: 88.5, aiOptimized: 78.4, improvement: "-11.4% (Lower Congestion)" },
  { category: "Track Waiting Time (min)", baseline: 14.2, aiOptimized: 6.8, improvement: "-52.1%" },
  { category: "Active Conflicts", baseline: 3, aiOptimized: 0, improvement: "-100%" }
];
