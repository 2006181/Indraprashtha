import { SAMPLE_CONFLICTS } from "../data/scenarios";
import type { Conflict } from "../types/railway";

export const getPredictions = async (): Promise<{
  conflicts: Conflict[];
  delayPropagationRisk: "LOW" | "MEDIUM" | "HIGH";
  confidenceScore: number;
}> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        conflicts: SAMPLE_CONFLICTS,
        delayPropagationRisk: "HIGH",
        confidenceScore: 93.1
      });
    }, 200);
  });
};
