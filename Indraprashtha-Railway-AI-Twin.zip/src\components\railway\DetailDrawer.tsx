import React from "react";
import type { SelectedItem } from "../../hooks/useRailwayState";
import type { Train, Block, Signal, Station, Conflict } from "../../types/railway";
import { formatSpeed, formatDelay, getTrainTypeBadgeColor } from "../../utils/formatters";
import { X, Train as TrainIcon, Network, Radio, Building2, AlertTriangle } from "lucide-react";

interface DetailDrawerProps {
  selectedItem: SelectedItem | null;
  onClose: () => void;
}

export const DetailDrawer: React.FC<DetailDrawerProps> = ({ selectedItem, onClose }) => {
  if (!selectedItem) return null;

  const { type, data } = selectedItem;

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-slate-950 border-l border-slate-800 shadow-2xl z-40 flex flex-col font-mono text-xs select-none">
      {/* Drawer Header */}
      <div className="h-14 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          {type === "TRAIN" && <TrainIcon className="w-5 h-5 text-sky-400" />}
          {type === "BLOCK" && <Network className="w-5 h-5 text-emerald-400" />}
          {type === "SIGNAL" && <Radio className="w-5 h-5 text-amber-400" />}
          {type === "STATION" && <Building2 className="w-5 h-5 text-purple-400" />}
          {type === "CONFLICT" && <AlertTriangle className="w-5 h-5 text-rose-400" />}

          <div>
            <h3 className="font-bold text-slate-100 uppercase tracking-wide text-sm">{type} DETAILS</h3>
            <p className="text-[10px] text-slate-400">ID: {selectedItem.id}</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Drawer Body Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {type === "TRAIN" && (
          <TrainDetailsView train={data as Train} />
        )}
        {type === "BLOCK" && (
          <BlockDetailsView block={data as Block} />
        )}
        {type === "SIGNAL" && (
          <SignalDetailsView signal={data as Signal} />
        )}
        {type === "STATION" && (
          <StationDetailsView station={data as Station} />
        )}
        {type === "CONFLICT" && (
          <ConflictDetailsView conflict={data as Conflict} />
        )}
      </div>

      {/* Footer */}
      <div className="p-3 bg-slate-900/80 border-t border-slate-800 text-[10px] text-slate-500 text-center">
        TELEMETRY SYNCHRONIZED VIA DIGITAL TWIN ENGINE
      </div>
    </div>
  );
};

const TrainDetailsView: React.FC<{ train: Train }> = ({ train }) => {
  const delayInfo = formatDelay(train.delayMinutes);

  return (
    <div className="space-y-4">
      {/* Title Card */}
      <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-100 text-sm">{train.name}</span>
          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getTrainTypeBadgeColor(train.type)}`}>
            {train.type}
          </span>
        </div>
        <p className="text-slate-400">Train #{train.number} • Dir: {train.direction}</p>
      </div>

      {/* Speed & Delay Grid */}
      <div className="grid grid-cols-2 gap-2">
        <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
          <span className="text-slate-500 uppercase text-[10px]">CURRENT SPEED</span>
          <p className="text-lg font-bold text-cyan-400 mt-0.5">{formatSpeed(train.speed)}</p>
          <span className="text-[10px] text-slate-400">Target: {train.targetSpeed} km/h</span>
        </div>

        <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
          <span className="text-slate-500 uppercase text-[10px]">DELAY STATUS</span>
          <p className={`text-lg font-bold mt-0.5 ${delayInfo.color}`}>{delayInfo.text}</p>
          <span className="text-[10px] text-slate-400">Scheduled: {train.scheduledEta}</span>
        </div>
      </div>

      {/* Specifications */}
      <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-2">
        <h4 className="font-bold text-slate-300 text-xs border-b border-slate-800 pb-1">SPECIFICATIONS</h4>
        <div className="space-y-1 text-slate-400">
          <div className="flex justify-between"><span>Current Block:</span><span className="text-slate-200">{train.currentBlock}</span></div>
          <div className="flex justify-between"><span>Next Block:</span><span className="text-slate-200">{train.nextBlock}</span></div>
          <div className="flex justify-between"><span>Origin:</span><span className="text-slate-200">{train.origin}</span></div>
          <div className="flex justify-between"><span>Destination:</span><span className="text-slate-200">{train.destination}</span></div>
          <div className="flex justify-between"><span>Loco Driver:</span><span className="text-slate-200">{train.driverName || "N/A"}</span></div>
          <div className="flex justify-between"><span>Rake Length:</span><span className="text-slate-200">{train.lengthMeters} m</span></div>
          <div className="flex justify-between"><span>Gross Weight:</span><span className="text-slate-200">{train.weightTons} tons</span></div>
        </div>
      </div>
    </div>
  );
};

const BlockDetailsView: React.FC<{ block: Block }> = ({ block }) => (
  <div className="space-y-3">
    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-1">
      <h4 className="font-bold text-slate-100 text-sm">{block.name}</h4>
      <p className="text-slate-400">Track Type: {block.trackType}</p>
    </div>

    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-2">
      <div className="flex justify-between"><span>Occupancy State:</span><span className="font-bold text-emerald-400">{block.status}</span></div>
      <div className="flex justify-between"><span>Occupied By:</span><span className="text-slate-200">{block.occupiedByTrainId || "NONE (CLEAR)"}</span></div>
      <div className="flex justify-between"><span>Length:</span><span className="text-slate-200">{block.lengthMeters} m</span></div>
      <div className="flex justify-between"><span>Max Speed Limit:</span><span className="text-slate-200">{block.maxSpeedKmH} km/h</span></div>
      <div className="flex justify-between"><span>Utilization:</span><span className="text-purple-400 font-bold">{block.utilizationPercentage}%</span></div>
    </div>
  </div>
);

const SignalDetailsView: React.FC<{ signal: Signal }> = ({ signal }) => (
  <div className="space-y-3">
    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-1">
      <h4 className="font-bold text-slate-100 text-sm">{signal.name}</h4>
      <p className="text-slate-400">Route: {signal.controlledRoute}</p>
    </div>

    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-2">
      <div className="flex justify-between"><span>Signal Aspect:</span><span className={`font-bold ${signal.aspect === "RED" ? "text-rose-400" : signal.aspect === "YELLOW" ? "text-amber-400" : "text-emerald-400"}`}>{signal.aspect}</span></div>
      <div className="flex justify-between"><span>Current Block:</span><span className="text-slate-200">{signal.blockId}</span></div>
      <div className="flex justify-between"><span>Next Target Block:</span><span className="text-slate-200">{signal.nextBlockId}</span></div>
      <div className="flex justify-between"><span>Last Aspect Change:</span><span className="text-slate-400">{signal.lastChanged}</span></div>
    </div>
  </div>
);

const StationDetailsView: React.FC<{ station: Station }> = ({ station }) => (
  <div className="space-y-3">
    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-1">
      <h4 className="font-bold text-slate-100 text-sm">{station.name} [{station.code}]</h4>
      <p className="text-slate-400">Corridor Mileage: {station.mileageKm} km</p>
    </div>

    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-2">
      <h4 className="font-bold text-slate-300 border-b border-slate-800 pb-1">PLATFORM STATUS</h4>
      {station.platforms.map((p) => (
        <div key={p.number} className="flex justify-between text-xs py-1 border-b border-slate-800/40">
          <span>Platform #{p.number} ({p.lineType})</span>
          <span className={`font-bold ${p.status === "OCCUPIED" ? "text-amber-400" : "text-emerald-400"}`}>
            {p.status} {p.occupiedByTrainId ? `[${p.occupiedByTrainId}]` : ""}
          </span>
        </div>
      ))}
    </div>
  </div>
);

const ConflictDetailsView: React.FC<{ conflict: Conflict }> = ({ conflict }) => (
  <div className="space-y-3">
    <div className="p-3 rounded bg-rose-950/40 border border-rose-800/60 space-y-1">
      <div className="flex justify-between items-center">
        <h4 className="font-bold text-rose-300 text-sm">{conflict.type}</h4>
        <span className="px-2 py-0.5 rounded bg-rose-900 text-rose-200 font-bold text-[10px]">{conflict.severity}</span>
      </div>
      <p className="text-slate-300 mt-1">{conflict.description}</p>
    </div>

    <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-2">
      <div className="flex justify-between"><span>Impact Delay:</span><span className="text-rose-400 font-bold">+{conflict.impactMinutes} min</span></div>
      <div className="flex justify-between"><span>Affected Block:</span><span className="text-slate-200">{conflict.blockId}</span></div>
      <div className="flex justify-between"><span>Primary Train:</span><span className="text-sky-400">{conflict.primaryTrainId}</span></div>
      <div className="flex justify-between"><span>Secondary Train:</span><span className="text-amber-400">{conflict.secondaryTrainId || "N/A"}</span></div>
    </div>
  </div>
);
