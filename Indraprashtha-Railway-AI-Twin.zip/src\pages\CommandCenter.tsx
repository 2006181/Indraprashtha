import React from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { KpiBar } from "../components/layout/KpiBar";
import { DigitalTwinMap } from "../components/railway/DigitalTwinMap";
import { AiIntelligencePanel } from "../components/dashboard/AiIntelligencePanel";
import { DetailDrawer } from "../components/railway/DetailDrawer";

interface CommandCenterProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const {
    trains,
    blocks,
    signals,
    stations,
    conflicts,
    recommendation,
    metrics,
    selectedItem,
    setSelectedItem,
    isDemoModeActive,
    setIsDemoModeActive,
    currentDemoStepIndex,
    currentDemoStep,
    isApprovalApplied,
    applyRecommendation,
    selectTrain,
    selectBlock,
    selectSignal,
    selectStation,
    resetState
  } = railwayState;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col overflow-hidden">
          <KpiBar metrics={metrics} activeConflictsCount={conflicts.length} />

          {isDemoModeActive && (
            <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border-b border-purple-800/80 px-4 py-2 flex items-center justify-between font-mono text-xs z-10 shadow-lg">
              <div className="flex items-center space-x-3">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping" />
                <div>
                  <span className="font-bold text-purple-300 mr-2">SIH DEMO MODE:</span>
                  <span className="font-bold text-slate-100">{currentDemoStep.title}</span>
                  <span className="text-slate-400 ml-2">({currentDemoStep.timeString})</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-300 max-w-xl truncate hidden md:block">
                {currentDemoStep.description}
              </p>
              <div className="flex items-center space-x-1 text-purple-300 font-bold bg-purple-900/60 px-2 py-1 rounded border border-purple-700">
                <span>STEP {currentDemoStepIndex} / 5</span>
              </div>
            </div>
          )}

          <div className="flex-1 flex overflow-hidden p-3 gap-3">
            <div className="flex-1 relative h-full">
              <DigitalTwinMap
                trains={trains}
                blocks={blocks}
                signals={signals}
                stations={stations}
                onSelectTrain={selectTrain}
                onSelectBlock={selectBlock}
                onSelectSignal={selectSignal}
                onSelectStation={selectStation}
                selectedId={selectedItem?.id}
                highlightBlockId={currentDemoStep?.highlightBlockId}
                highlightTrainId={currentDemoStep?.highlightTrainId}
              />
            </div>

            <AiIntelligencePanel
              recommendation={recommendation}
              conflicts={conflicts}
              isApprovalApplied={isApprovalApplied}
              onApplyRecommendation={applyRecommendation}
            />
          </div>
        </div>
      </div>

      <DetailDrawer selectedItem={selectedItem} onClose={() => setSelectedItem(null)} />
    </div>
  );
};
