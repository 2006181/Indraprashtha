import { useState, useEffect, useCallback } from "react";
import type { Train, Block, Signal, Station, Conflict, AIRecommendation, MetricSummary } from "../types/railway";
import { INITIAL_TRAINS } from "../data/trains";
import { BLOCKS, SIGNALS, STATIONS } from "../data/railway";
import { SAMPLE_CONFLICTS, CURRENT_AI_RECOMMENDATION, SIH_DEMO_STEPS } from "../data/scenarios";
import { INITIAL_METRICS } from "../data/metrics";

export interface SelectedItem {
  type: "TRAIN" | "BLOCK" | "SIGNAL" | "STATION" | "CONFLICT";
  id: string;
  data: Train | Block | Signal | Station | Conflict;
}

export function useRailwayState() {
  const [trains, setTrains] = useState<Train[]>(INITIAL_TRAINS);
  const [blocks, setBlocks] = useState<Block[]>(BLOCKS);
  const [signals] = useState<Signal[]>(SIGNALS);
  const [stations] = useState<Station[]>(STATIONS);
  const [conflicts, setConflicts] = useState<Conflict[]>(SAMPLE_CONFLICTS);
  const [recommendation] = useState<AIRecommendation>(CURRENT_AI_RECOMMENDATION);
  const [metrics, setMetrics] = useState<MetricSummary>(INITIAL_METRICS);

  const [selectedItem, setSelectedItem] = useState<SelectedItem | null>(null);
  const [isDemoModeActive, setIsDemoModeActive] = useState<boolean>(false);
  const [currentDemoStepIndex, setCurrentDemoStepIndex] = useState<number>(1);
  const [isApprovalApplied, setIsApprovalApplied] = useState<boolean>(false);

  // Live simulation tick to move trains continuously
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);

  const tickSimulation = useCallback(() => {
    setTrains((prevTrains) =>
      prevTrains.map((t) => {
        if (t.status === "HOLD") return t;
        const delta = (t.speed / 100) * 0.4 * speedMultiplier;
        let newProgress = t.routeProgress + delta;
        if (newProgress > 98) newProgress = 5;

        // Determine current block index roughly by progress
        const blockNum = Math.min(25, Math.max(1, Math.floor((newProgress / 100) * 15) + 1));
        const blockId = blockNum < 10 ? `B0${blockNum}` : `B${blockNum}`;

        return {
          ...t,
          routeProgress: Number(newProgress.toFixed(1)),
          currentBlock: blockId
        };
      })
    );
  }, [speedMultiplier]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(tickSimulation, 1000 / speedMultiplier);
    return () => clearInterval(interval);
  }, [isPlaying, speedMultiplier, tickSimulation]);

  // Sync selectedItem data with live state changes
  useEffect(() => {
    if (!selectedItem) return;
    if (selectedItem.type === "TRAIN") {
      const updatedTrain = trains.find((t) => t.id === selectedItem.id);
      if (updatedTrain && updatedTrain !== selectedItem.data) {
        setSelectedItem((prev) => (prev ? { ...prev, data: updatedTrain } : null));
      }
    } else if (selectedItem.type === "BLOCK") {
      const updatedBlock = blocks.find((b) => b.id === selectedItem.id);
      if (updatedBlock && updatedBlock !== selectedItem.data) {
        setSelectedItem((prev) => (prev ? { ...prev, data: updatedBlock } : null));
      }
    }
  }, [trains, blocks, selectedItem]);

  // Demo Mode Automated Timeline
  useEffect(() => {
    if (!isDemoModeActive) return;

    const demoInterval = setInterval(() => {
      setCurrentDemoStepIndex((prev) => {
        const nextStep = prev >= 5 ? 1 : prev + 1;
        if (nextStep === 1) {
          setConflicts(SAMPLE_CONFLICTS);
          setIsApprovalApplied(false);
          setMetrics(INITIAL_METRICS);
        } else if (nextStep === 5) {
          setConflicts([]);
          setIsApprovalApplied(true);
          setMetrics((m) => ({
            ...m,
            avgDelayMinutes: 5.1,
            throughputPerHour: 9.4,
            activeConflictsCount: 0
          }));
        }
        return nextStep;
      });
    }, 6000);

    return () => clearInterval(demoInterval);
  }, [isDemoModeActive]);

  const selectTrain = (trainId: string) => {
    const train = trains.find((t) => t.id === trainId);
    if (train) setSelectedItem({ type: "TRAIN", id: trainId, data: train });
  };

  const selectBlock = (blockId: string) => {
    const block = blocks.find((b) => b.id === blockId);
    if (block) setSelectedItem({ type: "BLOCK", id: blockId, data: block });
  };

  const selectSignal = (signalId: string) => {
    const signal = signals.find((s) => s.id === signalId);
    if (signal) setSelectedItem({ type: "SIGNAL", id: signalId, data: signal });
  };

  const selectStation = (stationId: string) => {
    const station = stations.find((st) => st.id === stationId);
    if (station) setSelectedItem({ type: "STATION", id: stationId, data: station });
  };

  const selectConflict = (conflictId: string) => {
    const conflict = conflicts.find((c) => c.id === conflictId);
    if (conflict) setSelectedItem({ type: "CONFLICT", id: conflictId, data: conflict });
  };

  const applyRecommendation = () => {
    setIsApprovalApplied(true);
    setConflicts([]);
    setMetrics((prev) => ({
      ...prev,
      avgDelayMinutes: 5.1,
      delayTrendPercent: -39.2,
      throughputPerHour: 9.4,
      throughputTrendPercent: 14.8,
      activeConflictsCount: 0
    }));
    setTrains((prev) =>
      prev.map((t) =>
        t.id === "F21"
          ? { ...t, status: "HOLD", currentBlock: "L01", delayMinutes: 3 }
          : t.id === "E102"
          ? { ...t, speed: 110, status: "ON_TIME", delayMinutes: 0 }
          : t
      )
    );
  };

  const resetState = () => {
    setTrains(INITIAL_TRAINS);
    setBlocks(BLOCKS);
    setConflicts(SAMPLE_CONFLICTS);
    setMetrics(INITIAL_METRICS);
    setIsApprovalApplied(false);
    setIsDemoModeActive(false);
    setCurrentDemoStepIndex(1);
    setSelectedItem(null);
  };

  return {
    trains,
    blocks,
    signals,
    stations,
    conflicts,
    recommendation,
    metrics,
    selectedItem,
    setSelectedItem,
    isDemoModeActive,
    setIsDemoModeActive,
    currentDemoStepIndex,
    setCurrentDemoStepIndex,
    currentDemoStep: SIH_DEMO_STEPS.find((s) => s.stepIndex === currentDemoStepIndex) || SIH_DEMO_STEPS[0],
    isApprovalApplied,
    applyRecommendation,
    selectTrain,
    selectBlock,
    selectSignal,
    selectStation,
    selectConflict,
    isPlaying,
    setIsPlaying,
    speedMultiplier,
    setSpeedMultiplier,
    resetState
  };
}
