import React from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import {
  THROUGHPUT_TREND_DATA,
  DELAY_DISTRIBUTION_DATA,
  BLOCK_UTILIZATION_DATA,
  COMPARISON_METRICS
} from "../data/metrics";
import { BarChart3, TrendingUp, Gauge } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";

interface AnalyticsProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const Analytics: React.FC<AnalyticsProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const { conflicts, isDemoModeActive, setIsDemoModeActive, currentDemoStepIndex, resetState } = railwayState;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-y-auto font-mono text-xs select-none">
          <div className="flex items-center justify-between p-3 rounded bg-slate-900 border border-slate-800">
            <div className="flex items-center space-x-3">
              <BarChart3 className="w-5 h-5 text-cyan-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">SECTION THROUGHPUT & PERFORMANCE ANALYTICS</h2>
                <p className="text-slate-400">Historical performance metrics, delay profiles, block congestion heatmaps, and AI impact analysis</p>
              </div>
            </div>
            <div className="px-3 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold text-xs">
              TOTAL THROUGHPUT IMPROVEMENT: +14.8%
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="scada-panel p-4 space-y-2">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>THROUGHPUT TREND (TRAINS / HOUR)</span>
              </h3>
              <div className="h-52 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={THROUGHPUT_TREND_DATA}>
                    <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} domain={[5, 11]} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155" }} />
                    <Legend />
                    <Line type="monotone" dataKey="baseline" stroke="#f43f5e" strokeWidth={2} name="Baseline Manual" />
                    <Line type="monotone" dataKey="aiOptimized" stroke="#10b981" strokeWidth={2.5} name="AI Digital Twin" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="scada-panel p-4 space-y-2">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs flex items-center space-x-2">
                <Gauge className="w-4 h-4 text-purple-400" />
                <span>BLOCK UTILIZATION HEATMAP (%)</span>
              </h3>
              <div className="h-52 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={BLOCK_UTILIZATION_DATA} layout="vertical">
                    <XAxis type="number" stroke="#64748b" fontSize={10} domain={[0, 100]} />
                    <YAxis dataKey="block" type="category" stroke="#64748b" fontSize={10} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155" }} />
                    <Bar dataKey="utilization" fill="#a855f7" name="Utilization %" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="scada-panel p-4 space-y-2">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs flex items-center space-x-2">
                <BarChart3 className="w-4 h-4 text-amber-400" />
                <span>DELAY SEVERITY DISTRIBUTION</span>
              </h3>
              <div className="h-52 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={DELAY_DISTRIBUTION_DATA}>
                    <XAxis dataKey="range" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} />
                    <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155" }} />
                    <Bar dataKey="count" fill="#38bdf8" name="Train Count" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="scada-panel p-4 space-y-3">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs">
                BASELINE VS AI OPTIMIZED IMPACT SUMMARY
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-900 text-slate-400 uppercase border-b border-slate-800">
                    <tr>
                      <th className="p-2">METRIC CATEGORY</th>
                      <th className="p-2">BASELINE</th>
                      <th className="p-2">AI OPTIMIZED</th>
                      <th className="p-2 text-right">IMPROVEMENT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {COMPARISON_METRICS.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/60">
                        <td className="p-2 font-bold text-slate-100">{row.category}</td>
                        <td className="p-2 text-rose-400 font-mono">{row.baseline}</td>
                        <td className="p-2 text-emerald-400 font-mono font-bold">{row.aiOptimized}</td>
                        <td className="p-2 text-right font-bold text-cyan-400 font-mono">{row.improvement}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
