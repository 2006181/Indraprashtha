import React, { useState } from "react";
import type { AIRecommendation, Conflict } from "../../types/railway";
import { BrainCircuit, ShieldCheck, ArrowRight, Activity, HelpCircle, CheckCircle2 } from "lucide-react";
import { ExplainabilityModal } from "../optimization/ExplainabilityModal";

interface AiIntelligencePanelProps {
  recommendation: AIRecommendation;
  conflicts: Conflict[];
  isApprovalApplied: boolean;
  onApplyRecommendation: () => void;
}

export const AiIntelligencePanel: React.FC<AiIntelligencePanelProps> = ({
  recommendation,
  isApprovalApplied,
  onApplyRecommendation
}) => {
  const [showReasoningModal, setShowReasoningModal] = useState<boolean>(false);

  return (
    <div className="w-80 lg:w-96 bg-slate-950 border-l border-slate-800/80 p-3 flex flex-col h-full overflow-y-auto space-y-3 font-mono text-xs select-none">
      {/* Header */}
      <div className="flex items-center justify-between p-2.5 rounded bg-slate-900 border border-slate-800">
        <div className="flex items-center space-x-2">
          <BrainCircuit className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 uppercase tracking-wide">AI TRAFFIC INTELLIGENCE</span>
        </div>
        <div className="flex items-center space-x-1.5 text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 scada-pulse" />
          <span className="font-bold">ONLINE</span>
        </div>
      </div>

      {/* 1. Current Situation */}
      <div className="scada-panel p-3 space-y-2 border-l-2 border-l-amber-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold uppercase">
          <span className="flex items-center space-x-1.5">
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            <span>CURRENT SITUATION</span>
          </span>
          <span className="text-amber-400 text-[10px]">HIGH DENSITY</span>
        </div>
        <p className="text-slate-300 leading-relaxed text-[11px]">
          Traffic density is <span className="text-amber-400 font-bold">HIGH</span> between Block B05 and B08. 2 trains approaching potential crossing conflict at B08.
        </p>
      </div>

      {/* 2. Prediction */}
      <div className="scada-panel p-3 space-y-2 border-l-2 border-l-blue-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold uppercase">
          <span>DELAY PROPAGATION</span>
          <span className="text-cyan-400 font-bold">{recommendation.confidenceScore}% CONF</span>
        </div>

        <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between text-slate-200">
          <div>
            <span className="text-sky-400 font-bold">T102 (Shatabdi)</span>
            <p className="text-[10px] text-slate-400">+3 min → <span className="text-rose-400 font-bold">+7 min</span></p>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-500" />
          <div className="text-right">
            <span className="text-amber-400 font-bold">F21 (Freight)</span>
            <p className="text-[10px] text-slate-400">+8 min → <span className="text-rose-400 font-bold">+15 min</span></p>
          </div>
        </div>
      </div>

      {/* 3. AI Recommendation (Visually Prominent) */}
      <div className="scada-panel p-3.5 space-y-3 bg-gradient-to-b from-cyan-950/40 to-slate-900 border-2 border-cyan-500/60 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-cyan-300 uppercase tracking-wide flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>RECOMMENDED DISPATCH ACTION</span>
          </span>
          <span className="px-1.5 py-0.5 rounded bg-cyan-900 text-cyan-200 text-[10px] font-bold">
            AI OPTIMIZED
          </span>
        </div>

        {/* Action Title */}
        <div className="p-2.5 rounded bg-slate-900/90 border border-cyan-800/60 space-y-1">
          <p className="font-bold text-slate-100 text-xs leading-snug">{recommendation.actionTitle}</p>
          <p className="text-[10px] text-slate-400">Target: {recommendation.targetTrainId} • Location: {recommendation.holdLocation}</p>
        </div>

        {/* Expected Results Metrics Grid */}
        <div>
          <span className="text-[10px] font-bold text-slate-400 uppercase">EXPECTED RESULT</span>
          <div className="grid grid-cols-3 gap-2 mt-1.5 text-center">
            <div className="p-2 rounded bg-emerald-950/60 border border-emerald-800/50">
              <span className="text-[10px] text-slate-400 block">Delay</span>
              <span className="text-xs font-bold text-emerald-400">↓ 39.2%</span>
            </div>
            <div className="p-2 rounded bg-cyan-950/60 border border-cyan-800/50">
              <span className="text-[10px] text-slate-400 block">Throughput</span>
              <span className="text-xs font-bold text-cyan-400">↑ 14.8%</span>
            </div>
            <div className="p-2 rounded bg-purple-950/60 border border-purple-800/50">
              <span className="text-[10px] text-slate-400 block">Conflicts</span>
              <span className="text-xs font-bold text-purple-400">0</span>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => setShowReasoningModal(true)}
            className="w-full flex items-center justify-center space-x-1.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>VIEW REASON</span>
          </button>

          <button
            onClick={onApplyRecommendation}
            disabled={isApprovalApplied}
            className={`w-full flex items-center justify-center space-x-1 py-2 rounded font-bold transition-all shadow-md ${
              isApprovalApplied
                ? "bg-emerald-900 text-emerald-300 border border-emerald-700 cursor-default"
                : "bg-cyan-600 hover:bg-cyan-500 text-white ring-1 ring-cyan-400/50"
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{isApprovalApplied ? "APPROVED" : "APPROVE DISPATCH"}</span>
          </button>
        </div>

        <p className="text-[10px] text-slate-400 text-center font-sans">
          Controller approval required before execution.
        </p>
      </div>

      {/* Safety Validation Check Box */}
      <div className="scada-panel p-3 space-y-2 border-l-2 border-l-emerald-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold uppercase">
          <span>SAFETY ENGINE STATUS</span>
          <span className="text-emerald-400 text-[10px] font-bold">ALL PASSED</span>
        </div>
        <div className="space-y-1 text-[10px]">
          {recommendation.safetyValidations.slice(0, 3).map((val, idx) => (
            <div key={idx} className="flex items-center justify-between text-slate-300">
              <span className="truncate">{val.name}</span>
              <span className="text-emerald-400 font-bold ml-2">✓ PASSED</span>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {showReasoningModal && (
        <ExplainabilityModal
          recommendation={recommendation}
          onClose={() => setShowReasoningModal(false)}
        />
      )}
    </div>
  );
};
