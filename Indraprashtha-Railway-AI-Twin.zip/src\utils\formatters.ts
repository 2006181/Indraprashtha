export const formatSpeed = (speedKmH: number): string => {
  return `${Math.round(speedKmH)} km/h`;
};

export const formatDelay = (delayMinutes: number): { text: string; isDelayed: boolean; color: string } => {
  if (delayMinutes <= 0) {
    return { text: "On Time", isDelayed: false, color: "text-emerald-400" };
  }
  if (delayMinutes <= 3) {
    return { text: `+${delayMinutes} min`, isDelayed: true, color: "text-amber-400" };
  }
  return { text: `+${delayMinutes} min`, isDelayed: true, color: "text-rose-400" };
};

export const formatPercentage = (val: number): string => {
  return `${val.toFixed(1)}%`;
};

export const formatTimeIST = (date: Date = new Date()): string => {
  return date.toLocaleTimeString("en-IN", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }) + " IST";
};

export const getTrainTypeBadgeColor = (type: string): string => {
  switch (type) {
    case "EXPRESS":
      return "bg-sky-950/80 text-sky-400 border-sky-600/40";
    case "PASSENGER":
      return "bg-emerald-950/80 text-emerald-400 border-emerald-600/40";
    case "FREIGHT":
      return "bg-amber-950/80 text-amber-400 border-amber-600/40";
    case "MAINTENANCE":
      return "bg-purple-950/80 text-purple-400 border-purple-600/40";
    default:
      return "bg-slate-800 text-slate-300 border-slate-700";
  }
};

export const getStatusColor = (status: string): string => {
  switch (status) {
    case "CLEAR":
    case "SAFE":
    case "ON_TIME":
    case "HEALTHY":
    case "GREEN":
      return "text-emerald-400 bg-emerald-950/50 border-emerald-600/40";
    case "RESTRICTED":
    case "DELAYED":
    case "WARNING":
    case "DEGRADED":
    case "YELLOW":
    case "MEDIUM":
      return "text-amber-400 bg-amber-950/50 border-amber-600/40";
    case "OCCUPIED":
    case "BLOCKED":
    case "CRITICAL":
    case "OFFLINE":
    case "RED":
    case "HIGH":
      return "text-rose-400 bg-rose-950/50 border-rose-600/40";
    case "HOLD":
    case "PURPLE":
      return "text-purple-400 bg-purple-950/50 border-purple-600/40";
    default:
      return "text-slate-400 bg-slate-800 border-slate-700";
  }
};
