import { INITIAL_TRAINS } from "../data/trains";
import type { Train } from "../types/railway";

export const getTrains = async (): Promise<Train[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(INITIAL_TRAINS);
    }, 120);
  });
};

export const updateTrainSpeed = async (
  trainId: string,
  newSpeedKmH: number
): Promise<{ success: boolean; trainId: string; speed: number }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, trainId, speed: newSpeedKmH });
    }, 180);
  });
};
