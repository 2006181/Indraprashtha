import { useState } from "react";
import { useRailwayState } from "./hooks/useRailwayState";
import type { NavTab } from "./components/layout/Sidebar";
import { CommandCenter } from "./pages/CommandCenter";
import { DigitalTwin } from "./pages/DigitalTwin";
import { TrafficMonitor } from "./pages/TrafficMonitor";
import { ScenarioSimulator } from "./pages/ScenarioSimulator";
import { AIInsights } from "./pages/AIInsights";
import { Analytics } from "./pages/Analytics";
import { SystemHealth } from "./pages/SystemHealth";

export function App() {
  const [activeTab, setActiveTab] = useState<NavTab>("command");
  const railwayState = useRailwayState();

  return (
    <div className="w-screen h-screen bg-[#080c14] overflow-hidden select-none">
      {activeTab === "command" && (
        <CommandCenter
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "twin" && (
        <DigitalTwin
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "traffic" && (
        <TrafficMonitor
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "scenarios" && (
        <ScenarioSimulator
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "ai" && (
        <AIInsights
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "analytics" && (
        <Analytics
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
      {activeTab === "health" && (
        <SystemHealth
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          railwayState={railwayState}
        />
      )}
    </div>
  );
}

export default App;
