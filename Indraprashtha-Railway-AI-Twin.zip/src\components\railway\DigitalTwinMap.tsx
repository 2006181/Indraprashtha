import React, { useState } from "react";
import type { Train, Block, Signal, Station, Conflict } from "../../types/railway";
import { calculateTrainCoordinates } from "../../utils/calculations";
import { ZoomIn, ZoomOut, Maximize2, Flame } from "lucide-react";

interface DigitalTwinMapProps {
  trains: Train[];
  blocks: Block[];
  signals: Signal[];
  stations: Station[];
  conflicts?: Conflict[];
  onSelectTrain: (trainId: string) => void;
  onSelectBlock: (blockId: string) => void;
  onSelectSignal: (signalId: string) => void;
  onSelectStation: (stationId: string) => void;
  selectedId?: string;
  highlightBlockId?: string;
  highlightTrainId?: string;
}

export const DigitalTwinMap: React.FC<DigitalTwinMapProps> = ({
  trains,
  blocks,
  signals,
  stations,
  conflicts = [],
  onSelectTrain,
  onSelectBlock,
  onSelectSignal,
  onSelectStation,
  selectedId,
  highlightBlockId,
  highlightTrainId
}) => {
  const [showHeatmap, setShowHeatmap] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [selectedTrackFilter, setSelectedTrackFilter] = useState<"ALL" | "MAIN" | "LOOPS">("ALL");

  return (
    <div className="relative w-full h-full bg-slate-950 border border-slate-800/80 rounded-md overflow-hidden flex flex-col select-none shadow-2xl">
      {/* Top Map Toolbar */}
      <div className="h-10 bg-slate-900/90 border-b border-slate-800 px-4 flex items-center justify-between z-10 font-mono text-xs text-slate-300">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 scada-pulse" />
            <span className="font-bold text-slate-100 tracking-wide">DIGITAL TWIN SCHEMATIC</span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Layer Filter Pills */}
          <div className="flex items-center space-x-1">
            <button
              onClick={() => setSelectedTrackFilter("ALL")}
              className={`px-2 py-0.5 rounded text-[11px] ${
                selectedTrackFilter === "ALL" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              All Lines
            </button>
            <button
              onClick={() => setSelectedTrackFilter("MAIN")}
              className={`px-2 py-0.5 rounded text-[11px] ${
                selectedTrackFilter === "MAIN" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Main Lines
            </button>
            <button
              onClick={() => setSelectedTrackFilter("LOOPS")}
              className={`px-2 py-0.5 rounded text-[11px] ${
                selectedTrackFilter === "LOOPS" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Loop Sidings
            </button>
          </div>
        </div>

        {/* Right Toolbar Controls */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-[11px] font-semibold border transition-all ${
              showHeatmap ? "bg-amber-950/80 text-amber-400 border-amber-600/50" : "bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200"
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>{showHeatmap ? "HEATMAP ON" : "HEATMAP OFF"}</span>
          </button>

          <div className="flex items-center space-x-1 border-l border-slate-800 pl-3">
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.8, z - 0.1))}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] text-slate-400 w-9 text-center">{Math.round(zoomLevel * 100)}%</span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.5, z + 0.1))}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1.0)}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 ml-1"
              title="Reset View"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="flex-1 w-full overflow-auto bg-[#070b12] flex items-center justify-center p-4">
        <div style={{ transform: `scale(${zoomLevel})`, transformOrigin: "center center" }} className="transition-transform duration-200">
          <svg viewBox="0 0 1400 440" className="w-[1360px] h-[400px] overflow-visible">
            {/* Grid background pattern */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#0f172a" strokeWidth="1" />
              </pattern>
            </defs>

            <rect width="1400" height="440" fill="url(#grid)" />

            {/* Direction Arrows & Track Headers */}
            <g fontFamily="monospace" fontSize="10" fill="#64748b" fontWeight="bold">
              <text x="60" y="170">NORTHBOUND UP MAIN LINE →</text>
              <text x="1220" y="275">← SOUTHBOUND DOWN MAIN LINE</text>
            </g>

            {/* BLOCK TRACK LINES */}
            {blocks.map((block) => {
              if (selectedTrackFilter === "MAIN" && block.trackType === "LOOP") return null;
              if (selectedTrackFilter === "LOOPS" && (block.trackType === "MAIN_UP" || block.trackType === "MAIN_DOWN")) return null;

              const isHighlighted = block.id === highlightBlockId || block.id === selectedId;
              const isOccupied = block.status === "OCCUPIED";
              const isRestricted = block.status === "RESTRICTED";
              const isBlocked = block.status === "BLOCKED";
              const hasConflict = conflicts.some((c) => c.blockId === block.id);

              let strokeColor = "#334155";
              if (isOccupied) strokeColor = "#f43f5e";
              else if (isRestricted) strokeColor = "#f59e0b";
              else if (isBlocked) strokeColor = "#e11d48";
              else strokeColor = "#10b981";

              if (showHeatmap) {
                if (block.utilizationPercentage > 85) strokeColor = "#ef4444";
                else if (block.utilizationPercentage > 60) strokeColor = "#f59e0b";
                else strokeColor = "#10b981";
              }

              const midX = (block.startCoord.x + block.endCoord.x) / 2;

              return (
                <g
                  key={block.id}
                  onClick={() => onSelectBlock(block.id)}
                  className="cursor-pointer group"
                >
                  {isHighlighted && (
                    <line
                      x1={block.startCoord.x}
                      y1={block.startCoord.y}
                      x2={block.endCoord.x}
                      y2={block.endCoord.y}
                      stroke="#38bdf8"
                      strokeWidth="12"
                      strokeOpacity="0.4"
                      strokeLinecap="round"
                    />
                  )}

                  <line
                    x1={block.startCoord.x}
                    y1={block.startCoord.y}
                    x2={block.endCoord.x}
                    y2={block.endCoord.y}
                    stroke={strokeColor}
                    strokeWidth={block.trackType === "LOOP" ? "4" : "6"}
                    strokeDasharray={block.trackType === "LOOP" ? "6 4" : "none"}
                    strokeLinecap="round"
                  />

                  {/* Active Conflict Warning Pulse */}
                  {hasConflict && (
                    <g transform={`translate(${midX}, ${block.startCoord.y - 32})`}>
                      <circle r="12" fill="#ef4444" opacity="0.3" className="animate-ping" />
                      <polygon points="0,-8 7,5 -7,5" fill="#f43f5e" stroke="#ffffff" strokeWidth="1" />
                    </g>
                  )}

                  <rect
                    x={midX - 16}
                    y={block.startCoord.y + (block.trackType === "MAIN_UP" ? -18 : 12)}
                    width="32"
                    height="14"
                    rx="2"
                    fill="#0f172a"
                    stroke={isHighlighted ? "#38bdf8" : strokeColor}
                    strokeWidth="1"
                  />
                  <text
                    x={midX}
                    y={block.startCoord.y + (block.trackType === "MAIN_UP" ? -8 : 22)}
                    fill={isHighlighted ? "#38bdf8" : "#94a3b8"}
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {block.id}
                  </text>
                </g>
              );
            })}

            {/* STATIONS & PLATFORMS */}
            {stations.map((station) => (
              <g
                key={station.id}
                onClick={() => onSelectStation(station.id)}
                className="cursor-pointer group"
              >
                <rect
                  x={station.coord.x - 22}
                  y={130}
                  width="44"
                  height="160"
                  fill="#020617"
                  stroke={station.id === selectedId ? "#38bdf8" : "#1e293b"}
                  strokeWidth="1.5"
                  rx="4"
                  opacity="0.85"
                />

                <rect
                  x={station.coord.x - 42}
                  y={105}
                  width="84"
                  height="22"
                  rx="3"
                  fill="#0f172a"
                  stroke="#334155"
                  strokeWidth="1"
                />
                <text
                  x={station.coord.x}
                  y={120}
                  fill="#f1f5f9"
                  fontSize="10"
                  fontFamily="monospace"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {station.name.toUpperCase()}
                </text>
                <text
                  x={station.coord.x}
                  y={132}
                  fill="#64748b"
                  fontSize="8"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  [{station.code}]
                </text>
              </g>
            ))}

            {/* SIGNALS */}
            {signals.map((sig) => {
              let aspectColor = "#10b981";
              if (sig.aspect === "YELLOW") aspectColor = "#f59e0b";
              if (sig.aspect === "RED") aspectColor = "#f43f5e";

              return (
                <g
                  key={sig.id}
                  onClick={() => onSelectSignal(sig.id)}
                  className="cursor-pointer"
                >
                  <line
                    x1={sig.coord.x}
                    y1={sig.coord.y}
                    x2={sig.coord.x}
                    y2={sig.coord.y + 14}
                    stroke="#475569"
                    strokeWidth="2"
                  />
                  <rect
                    x={sig.coord.x - 5}
                    y={sig.coord.y - 12}
                    width="10"
                    height="14"
                    fill="#0f172a"
                    stroke="#334155"
                    strokeWidth="1"
                    rx="2"
                  />
                  <circle
                    cx={sig.coord.x}
                    cy={sig.coord.y - 5}
                    r="4"
                    fill={aspectColor}
                    className={sig.aspect === "RED" ? "scada-pulse" : ""}
                  />
                  <text
                    x={sig.coord.x}
                    y={sig.coord.y - 15}
                    fill="#94a3b8"
                    fontSize="8"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {sig.id}
                  </text>
                </g>
              );
            })}

            {/* MOVING TRAINS */}
            {trains.map((train) => {
              const coords = calculateTrainCoordinates(train, blocks);
              const isSelected = train.id === selectedId || train.id === highlightTrainId;

              let typeColor = "#0284c7";
              if (train.type === "FREIGHT") typeColor = "#f59e0b";
              if (train.type === "PASSENGER") typeColor = "#10b981";
              if (train.type === "MAINTENANCE") typeColor = "#a855f7";

              return (
                <g
                  key={train.id}
                  onClick={() => onSelectTrain(train.id)}
                  className="cursor-pointer transition-all duration-500 group"
                  transform={`translate(${coords.x}, ${coords.y})`}
                >
                  {isSelected && (
                    <circle
                      cx="0"
                      cy="0"
                      r="22"
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="2"
                      strokeDasharray="4 2"
                      className="animate-spin"
                    />
                  )}

                  <rect
                    x="-18"
                    y="-10"
                    width="36"
                    height="20"
                    rx="4"
                    fill={typeColor}
                    stroke={isSelected ? "#ffffff" : "#020617"}
                    strokeWidth="1.5"
                    className="shadow-lg"
                  />

                  <text
                    x="0"
                    y="3"
                    fill="#ffffff"
                    fontSize="11"
                    fontFamily="sans-serif"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {train.direction === "UP" ? "➔" : "⬅"}
                  </text>

                  <rect
                    x="-24"
                    y="-30"
                    width="48"
                    height="16"
                    rx="2"
                    fill="#090d16"
                    stroke={typeColor}
                    strokeWidth="1"
                  />
                  <text
                    x="0"
                    y="-19"
                    fill="#f8fafc"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {train.id} {train.speed}k
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Legend Footer */}
      <div className="h-8 bg-slate-900/95 border-t border-slate-800 px-4 flex items-center justify-between font-mono text-[11px] text-slate-400">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1 bg-sky-500 rounded" />
            <span>Express</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1 bg-emerald-500 rounded" />
            <span>Passenger</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1 bg-amber-500 rounded" />
            <span>Freight</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-1 bg-purple-500 rounded" />
            <span>Maintenance</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Signal Green</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>Signal Yellow</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>Signal Red</span>
          </div>
        </div>
      </div>
    </div>
  );
};
