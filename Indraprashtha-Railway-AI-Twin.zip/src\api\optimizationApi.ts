import { CURRENT_AI_RECOMMENDATION } from "../data/scenarios";
import type { AIRecommendation } from "../types/railway";

export const getAIRecommendation = async (): Promise<AIRecommendation> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(CURRENT_AI_RECOMMENDATION);
    }, 250);
  });
};

export const approveRecommendation = async (
  _recommendationId: string
): Promise<{ success: boolean; appliedTimestamp: string; statusMessage: string }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        appliedTimestamp: new Date().toLocaleTimeString() + " IST",
        statusMessage: "Controller Approval logged. Signals & Switches updated automatically."
      });
    }, 300);
  });
};
