import { WHAT_IF_SCENARIOS } from "../data/scenarios";
import type { Scenario, Strategy } from "../types/railway";

export const runSimulationScenario = async (
  scenarioId: string
): Promise<{ scenario: Scenario; strategies: Strategy[]; executionTimeMs: number }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const match = WHAT_IF_SCENARIOS.find((s) => s.id === scenarioId) || WHAT_IF_SCENARIOS[0];
      resolve({
        scenario: match,
        strategies: match.strategies,
        executionTimeMs: 820
      });
    }, 450);
  });
};
