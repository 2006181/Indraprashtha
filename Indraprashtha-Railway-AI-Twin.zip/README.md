# Smart India Hackathon 2025 (SIH25022) — AI Railway Digital Twin Control Center

### Problem Statement
**Maximizing Section Throughput Using AI-Powered Precise Train Traffic Control**

An operational **AI-Powered Railway Digital Twin & Traffic Control Decision Support System** designed for modern railway traffic management control rooms.

---

## 🌟 Key Features

1. **SCADA Mission Control Interface**: Deep dark navy/charcoal styling (`#080C14`), crisp borders, high-contrast operational status colors, and zero generic dashboard elements.
2. **Interactive SVG Railway Digital Twin**: Vector schematic canvas covering the **Delhi–North Corridor (Delhi Jn to Sonipat Jn, 44 km)** with 8 stations, 25 block sections, 12 signals, loop sidings, crossovers, live train position interpolation, heatmap mode, and inspect drawers.
3. **AI Traffic Intelligence & Decision Support Panel**: Live traffic forecasts, delay propagation predictions, visually prominent AI recommendation card (`Delay ↓ 39.2%`, `Throughput ↑ 14.8%`, `Conflicts = 0`), and an **Explainable AI Audit Modal** ("WHY THIS ACTION?") displaying a 5-point rationale and 5 safety constraint checks.
4. **What-If Scenario Simulator**: Delay injection sliders, track blockage selectors, dynamic strategy comparison cards, Recharts comparative bar charts, and playback speed controls (1x–10x).
5. **Roster, Analytics & System Health**: Traffic monitor roster, ML model evaluation cards, Recharts visual analytics, and subsystem telemetry health indicators.
6. **Automated SIH Presentation Demo Mode**: Step-by-step 5-stage automated timeline built for SIH jury presentations.

---

## 🚀 Quick Start

### Prerequisites
- Node.js (v18 or higher)
- npm (v9 or higher)

### Installation & Local Run
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build production bundle
npm run build
```

---

## 📂 Architecture

```text
src/
├── api/                   # Service layer abstraction (railway, trains, simulation, predictions, recommendations)
├── types/                 # TypeScript interfaces (Train, Block, Signal, Station, Conflict, Strategy, AIRecommendation)
├── data/                  # Deterministic mock dataset (Delhi-North corridor geometry, 20 trains, scenarios, metrics)
├── utils/                 # Speed, delay, ETA, and headway safety math
├── hooks/                 # State management & simulation engine hooks (useRailwayState, useSimulation, useWebSocket)
├── components/            # SCADA layout, SVG Digital Twin map, AI Intelligence panel, Explainability modal
└── pages/                 # CommandCenter, DigitalTwin, TrafficMonitor, ScenarioSimulator, AIInsights, Analytics, SystemHealth
```

---

## 🏆 SIH 2025 Presentation Demo Mode

Click the **`[ START SIH DEMO MODE ]`** button in the top header to run an automated 5-step presentation script:
- **Step 1**: Baseline Normal Section Flow (10:00)
- **Step 2**: Freight Delay Disruption F21 Injection (10:05)
- **Step 3**: Digital Twin & AI Crossing Bottleneck Prediction (10:07)
- **Step 4**: AI Strategy Evaluation & Safety Validation (10:09)
- **Step 5**: Controller Approval & Optimized Section Flow (10:11)
