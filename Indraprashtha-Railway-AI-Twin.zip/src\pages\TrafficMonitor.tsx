import React, { useState } from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { DetailDrawer } from "../components/railway/DetailDrawer";
import { formatSpeed, formatDelay, getTrainTypeBadgeColor } from "../utils/formatters";
import { TrainFront, Search, Eye } from "lucide-react";

interface TrafficMonitorProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const TrafficMonitor: React.FC<TrafficMonitorProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const {
    trains,
    conflicts,
    selectedItem,
    setSelectedItem,
    isDemoModeActive,
    setIsDemoModeActive,
    currentDemoStepIndex,
    selectTrain,
    resetState
  } = railwayState;

  const [filterType, setFilterType] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const filteredTrains = trains.filter((train) => {
    if (filterType !== "ALL" && filterType !== "DELAYED" && train.type !== filterType) return false;
    if (filterType === "DELAYED" && train.delayMinutes <= 0) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        train.name.toLowerCase().includes(q) ||
        train.number.includes(q) ||
        train.id.toLowerCase().includes(q) ||
        train.currentBlock.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-hidden font-mono text-xs select-none">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded bg-slate-900 border border-slate-800">
            <div className="flex items-center space-x-3">
              <TrainFront className="w-5 h-5 text-sky-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">LIVE TRAFFIC ROSTER</h2>
                <p className="text-[11px] text-slate-400">Monitoring {filteredTrains.length} active trains in Delhi-North corridor</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 overflow-x-auto">
              {["ALL", "EXPRESS", "PASSENGER", "FREIGHT", "DELAYED"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterType(cat)}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                    filterType === cat
                      ? "bg-cyan-950 text-cyan-300 border border-cyan-700"
                      : "bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search train, block, number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-600"
              />
            </div>
          </div>

          <div className="flex-1 bg-slate-950 border border-slate-800 rounded overflow-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold sticky top-0 uppercase text-[11px]">
                <tr>
                  <th className="p-3">TRAIN ID / NAME</th>
                  <th className="p-3">TYPE</th>
                  <th className="p-3">DIR</th>
                  <th className="p-3">BLOCK</th>
                  <th className="p-3">SPEED</th>
                  <th className="p-3">SCHEDULED</th>
                  <th className="p-3">PREDICTED</th>
                  <th className="p-3">DELAY</th>
                  <th className="p-3">PRIORITY</th>
                  <th className="p-3">STATUS</th>
                  <th className="p-3 text-center">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredTrains.map((train) => {
                  const delayInfo = formatDelay(train.delayMinutes);
                  const isSelected = selectedItem?.id === train.id;

                  return (
                    <tr
                      key={train.id}
                      onClick={() => selectTrain(train.id)}
                      className={`hover:bg-slate-900/80 cursor-pointer transition-colors ${
                        isSelected ? "bg-cyan-950/40 border-l-4 border-l-cyan-400" : ""
                      }`}
                    >
                      <td className="p-3">
                        <div className="font-bold text-slate-100">{train.name}</div>
                        <div className="text-[10px] text-slate-400">#{train.number} • {train.id}</div>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getTrainTypeBadgeColor(train.type)}`}>
                          {train.type}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-slate-200">{train.direction}</td>
                      <td className="p-3 text-cyan-400 font-bold">{train.currentBlock}</td>
                      <td className="p-3 font-bold text-slate-200">{formatSpeed(train.speed)}</td>
                      <td className="p-3 text-slate-400">{train.scheduledEta}</td>
                      <td className="p-3 text-slate-300">{train.predictedEta}</td>
                      <td className="p-3 font-bold">
                        <span className={delayInfo.color}>{delayInfo.text}</span>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          train.priority === "HIGH" ? "bg-rose-950 text-rose-300 border border-rose-800" : "bg-slate-800 text-slate-300"
                        }`}>
                          {train.priority}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          train.status === "ON_TIME" ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-amber-950 text-amber-400 border border-amber-800"
                        }`}>
                          {train.status}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            selectTrain(train.id);
                          }}
                          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400"
                          title="Inspect Train Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <DetailDrawer selectedItem={selectedItem} onClose={() => setSelectedItem(null)} />
    </div>
  );
};
