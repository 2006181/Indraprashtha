import { BLOCKS, SIGNALS, STATIONS } from "../data/railway";
import type { Block, Signal, Station } from "../types/railway";

export const getRailwayState = async (): Promise<{
  stations: Station[];
  blocks: Block[];
  signals: Signal[];
}> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        stations: STATIONS,
        blocks: BLOCKS,
        signals: SIGNALS
      });
    }, 150);
  });
};

export const updateSignalAspect = async (
  signalId: string,
  newAspect: "GREEN" | "YELLOW" | "RED"
): Promise<{ success: boolean; signalId: string; aspect: string }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, signalId, aspect: newAspect });
    }, 200);
  });
};
