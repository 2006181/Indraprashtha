import React from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { SUBSYSTEM_HEALTH } from "../data/metrics";
import { Activity } from "lucide-react";

interface SystemHealthProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const SystemHealth: React.FC<SystemHealthProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const { conflicts, isDemoModeActive, setIsDemoModeActive, currentDemoStepIndex, resetState } = railwayState;

  const subsystems = [
    { name: "Digital Twin Engine", status: SUBSYSTEM_HEALTH.digitalTwin, latency: "84 ms", desc: "Real-time track occupancy & train position synchronization" },
    { name: "Simulation Engine", status: SUBSYSTEM_HEALTH.simulationEngine, latency: "24 Ticks/s", desc: "What-If timeline forward projection & playback" },
    { name: "ML Inference Engine", status: SUBSYSTEM_HEALTH.mlEngine, latency: "93.1% Acc", desc: "GNN graph delay propagation & ETA prediction" },
    { name: "Optimization Engine", status: SUBSYSTEM_HEALTH.optimizationEngine, latency: "0.82 sec", desc: "Mixed Integer Programming dispatch solver" },
    { name: "Safety Validation Engine", status: SUBSYSTEM_HEALTH.safetyEngine, latency: "100% Pass", desc: "Headway, overlap, and platform constraint verifier" }
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-y-auto font-mono text-xs select-none">
          <div className="flex items-center justify-between p-3 rounded bg-slate-900 border border-slate-800">
            <div className="flex items-center space-x-3">
              <Activity className="w-5 h-5 text-emerald-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">SUBSYSTEM TELEMETRY & SYSTEM HEALTH</h2>
                <p className="text-slate-400">Control center infrastructure telemetry, WebSocket connection health, tick rate, and processing latency</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-xs text-emerald-400 bg-emerald-950 px-3 py-1 rounded border border-emerald-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500 scada-pulse" />
              <span>ALL SUBSYSTEMS HEALTHY</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {subsystems.map((sub, idx) => (
              <div key={idx} className="scada-panel p-4 space-y-2 border-l-4 border-l-emerald-500">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100 text-sm">{sub.name}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800 text-[10px]">
                    ● {sub.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px]">{sub.desc}</p>
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 uppercase text-[10px]">Response Metric</span>
                  <span className="font-bold text-cyan-400 font-mono">{sub.latency}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="scada-panel p-4 space-y-3">
            <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-slate-800 pb-2">
              WEBSOCKET & TELEMETRY STREAM METRICS
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-500 uppercase text-[10px] block">Tick Rate</span>
                <span className="text-xl font-bold text-cyan-400 font-mono">{SUBSYSTEM_HEALTH.tickRatePerSec} events/sec</span>
              </div>
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-500 uppercase text-[10px] block">Prediction Latency</span>
                <span className="text-xl font-bold text-emerald-400 font-mono">{SUBSYSTEM_HEALTH.latencyMs} ms</span>
              </div>
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-500 uppercase text-[10px] block">Optimization Time</span>
                <span className="text-xl font-bold text-purple-400 font-mono">{SUBSYSTEM_HEALTH.optimizationTimeSec} sec</span>
              </div>
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <span className="text-slate-500 uppercase text-[10px] block">Data Freshness</span>
                <span className="text-xl font-bold text-blue-400 font-mono">{SUBSYSTEM_HEALTH.dataFreshnessSec} sec</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
