import React, { useState, useEffect } from "react";
import { Train, Bell, User, Play, RotateCcw } from "lucide-react";
import { formatTimeIST } from "../../utils/formatters";

interface HeaderProps {
  isDemoModeActive: boolean;
  onToggleDemoMode: () => void;
  onResetState: () => void;
  activeConflictsCount: number;
  currentDemoStepIndex?: number;
}

export const Header: React.FC<HeaderProps> = ({
  isDemoModeActive,
  onToggleDemoMode,
  onResetState,
  activeConflictsCount,
  currentDemoStepIndex = 1
}) => {
  const [timeString, setTimeString] = useState<string>(formatTimeIST());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeString(formatTimeIST());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="h-16 bg-slate-950 border-b border-slate-800/80 px-4 flex items-center justify-between z-30 sticky top-0">
      {/* Left branding */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center shadow-lg shadow-cyan-950/40">
            <Train className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-100 tracking-wider text-base font-mono">RAIL//AI</span>
              <span className="text-[10px] uppercase font-mono tracking-widest px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                SIH25022
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">Railway Traffic Intelligence Twin</p>
          </div>
        </div>

        <div className="h-6 w-px bg-slate-800 hidden md:block" />

        {/* Section info */}
        <div className="hidden lg:flex items-center space-x-3 font-mono text-xs">
          <div className="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded text-slate-300">
            <span className="text-slate-500 mr-1.5">SECTION:</span>
            <span className="font-semibold text-cyan-300">DELHI–NORTH CORRIDOR</span>
          </div>

          <div className="flex items-center space-x-1.5 bg-emerald-950/40 border border-emerald-800/50 px-2.5 py-1 rounded text-emerald-400 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 scada-pulse" />
            <span className="font-semibold uppercase tracking-wide">SYSTEM OPERATIONAL</span>
          </div>
        </div>
      </div>

      {/* Center Demo Mode Activator */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onToggleDemoMode}
          className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-md text-xs font-mono font-bold transition-all shadow-md ${
            isDemoModeActive
              ? "bg-purple-600 hover:bg-purple-500 text-white ring-2 ring-purple-400/50"
              : "bg-slate-900 hover:bg-slate-800 text-purple-400 border border-purple-800/50"
          }`}
        >
          <Play className={`w-3.5 h-3.5 ${isDemoModeActive ? "fill-white" : ""}`} />
          <span>{isDemoModeActive ? `DEMO MODE ACTIVE (STEP ${currentDemoStepIndex}/5)` : "START SIH DEMO MODE"}</span>
        </button>

        <button
          onClick={onResetState}
          title="Reset digital twin state"
          className="p-1.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-800 text-xs"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Right User & Live Clock */}
      <div className="flex items-center space-x-4">
        {/* Active alert count */}
        <div className="relative">
          <Bell className="w-5 h-5 text-slate-400 hover:text-slate-200 cursor-pointer" />
          {activeConflictsCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold font-mono w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
              {activeConflictsCount}
            </span>
          )}
        </div>

        {/* Live Clock */}
        <div className="text-right font-mono hidden sm:block">
          <div className="flex items-center justify-end space-x-1.5 text-xs text-emerald-400 font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 scada-pulse" />
            <span>LIVE</span>
          </div>
          <p className="text-xs text-slate-300 font-bold tracking-wider">{timeString}</p>
        </div>

        {/* Controller Profile */}
        <div className="flex items-center space-x-2 border-l border-slate-800 pl-3">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
            <User className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="hidden xl:block text-left">
            <p className="text-xs font-semibold text-slate-200 leading-tight">Control Room #4</p>
            <p className="text-[10px] text-slate-400 font-mono">Senior Controller</p>
          </div>
        </div>
      </div>
    </header>
  );
};
