import type { Station, Block, Signal } from "../types/railway";

export const STATIONS: Station[] = [
  {
    id: "ST_DELHI_JN",
    code: "DLI",
    name: "Delhi Junction",
    mileageKm: 0.0,
    coord: { x: 90, y: 220 },
    platforms: [
      { number: 1, status: "OCCUPIED", occupiedByTrainId: "E102", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" },
      { number: 3, status: "CLEAR", lineType: "LOOP" },
      { number: 4, status: "RESERVED", occupiedByTrainId: "P18", lineType: "LOOP" }
    ],
    incomingTrainCount: 3,
    outgoingTrainCount: 2
  },
  {
    id: "ST_SUBZI_MANDI",
    code: "SZM",
    name: "Subzi Mandi",
    mileageKm: 3.2,
    coord: { x: 260, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" },
      { number: 3, status: "OCCUPIED", occupiedByTrainId: "F21", lineType: "LOOP" }
    ],
    incomingTrainCount: 2,
    outgoingTrainCount: 1
  },
  {
    id: "ST_AZADPUR",
    code: "AZP",
    name: "Azadpur",
    mileageKm: 7.5,
    coord: { x: 430, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" }
    ],
    incomingTrainCount: 1,
    outgoingTrainCount: 2
  },
  {
    id: "ST_ADARSH_NAGAR",
    code: "ANDI",
    name: "Adarsh Nagar",
    mileageKm: 11.0,
    coord: { x: 600, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "OCCUPIED", occupiedByTrainId: "P44", lineType: "MAIN" },
      { number: 3, status: "CLEAR", lineType: "LOOP" }
    ],
    incomingTrainCount: 2,
    outgoingTrainCount: 1
  },
  {
    id: "ST_BADLI",
    code: "BHD",
    name: "Badli",
    mileageKm: 15.4,
    coord: { x: 770, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" },
      { number: 3, status: "CLEAR", lineType: "LOOP" }
    ],
    incomingTrainCount: 1,
    outgoingTrainCount: 3
  },
  {
    id: "ST_HOLAMBI",
    code: "HUK",
    name: "Holambi Kalan",
    mileageKm: 21.0,
    coord: { x: 940, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" }
    ],
    incomingTrainCount: 1,
    outgoingTrainCount: 1
  },
  {
    id: "ST_NARELA",
    code: "NUR",
    name: "Narela",
    mileageKm: 27.5,
    coord: { x: 1110, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "CLEAR", lineType: "MAIN" },
      { number: 3, status: "OCCUPIED", occupiedByTrainId: "F88", lineType: "LOOP" }
    ],
    incomingTrainCount: 2,
    outgoingTrainCount: 2
  },
  {
    id: "ST_SONIPAT",
    code: "SNP",
    name: "Sonipat Jn",
    mileageKm: 44.0,
    coord: { x: 1280, y: 220 },
    platforms: [
      { number: 1, status: "CLEAR", lineType: "MAIN" },
      { number: 2, status: "OCCUPIED", occupiedByTrainId: "E205", lineType: "MAIN" },
      { number: 3, status: "CLEAR", lineType: "LOOP" },
      { number: 4, status: "CLEAR", lineType: "LOOP" }
    ],
    incomingTrainCount: 4,
    outgoingTrainCount: 2
  }
];

export const BLOCKS: Block[] = [
  // MAIN UP TRACK (y: 190)
  {
    id: "B01",
    name: "Block 01 (Delhi Jn Yard)",
    trackType: "MAIN_UP",
    lengthMeters: 1200,
    maxSpeedKmH: 90,
    status: "OCCUPIED",
    occupiedByTrainId: "E102",
    utilizationPercentage: 88,
    stationId: "ST_DELHI_JN",
    signalId: "S01",
    startCoord: { x: 60, y: 190 },
    endCoord: { x: 150, y: 190 }
  },
  {
    id: "B02",
    name: "Block 02 (Delhi - Subzi Mandi)",
    trackType: "MAIN_UP",
    lengthMeters: 1500,
    maxSpeedKmH: 110,
    status: "CLEAR",
    utilizationPercentage: 45,
    signalId: "S02",
    startCoord: { x: 150, y: 190 },
    endCoord: { x: 230, y: 190 }
  },
  {
    id: "B03",
    name: "Block 03 (Subzi Mandi Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1100,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 55,
    stationId: "ST_SUBZI_MANDI",
    signalId: "S03",
    startCoord: { x: 230, y: 190 },
    endCoord: { x: 310, y: 190 }
  },
  {
    id: "B04",
    name: "Block 04 (Subzi Mandi - Azadpur)",
    trackType: "MAIN_UP",
    lengthMeters: 1800,
    maxSpeedKmH: 110,
    status: "CLEAR",
    utilizationPercentage: 62,
    signalId: "S04",
    startCoord: { x: 310, y: 190 },
    endCoord: { x: 400, y: 190 }
  },
  {
    id: "B05",
    name: "Block 05 (Azadpur Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1300,
    maxSpeedKmH: 90,
    status: "OCCUPIED",
    occupiedByTrainId: "E108",
    utilizationPercentage: 92,
    stationId: "ST_AZADPUR",
    signalId: "S05",
    startCoord: { x: 400, y: 190 },
    endCoord: { x: 480, y: 190 }
  },
  {
    id: "B06",
    name: "Block 06 (Azadpur - Adarsh Nagar)",
    trackType: "MAIN_UP",
    lengthMeters: 1600,
    maxSpeedKmH: 110,
    status: "RESTRICTED",
    utilizationPercentage: 79,
    signalId: "S06",
    startCoord: { x: 480, y: 190 },
    endCoord: { x: 570, y: 190 }
  },
  {
    id: "B07",
    name: "Block 07 (Adarsh Nagar Approach)",
    trackType: "MAIN_UP",
    lengthMeters: 1400,
    maxSpeedKmH: 90,
    status: "OCCUPIED",
    occupiedByTrainId: "F21",
    utilizationPercentage: 96,
    stationId: "ST_ADARSH_NAGAR",
    signalId: "S07",
    startCoord: { x: 570, y: 190 },
    endCoord: { x: 650, y: 190 }
  },
  {
    id: "B08",
    name: "Block 08 (Adarsh Nagar - Badli)",
    trackType: "MAIN_UP",
    lengthMeters: 2000,
    maxSpeedKmH: 120,
    status: "RESTRICTED",
    utilizationPercentage: 84,
    signalId: "S08",
    startCoord: { x: 650, y: 190 },
    endCoord: { x: 740, y: 190 }
  },
  {
    id: "B09",
    name: "Block 09 (Badli Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1200,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 40,
    stationId: "ST_BADLI",
    startCoord: { x: 740, y: 190 },
    endCoord: { x: 820, y: 190 }
  },
  {
    id: "B10",
    name: "Block 10 (Badli - Holambi Kalan)",
    trackType: "MAIN_UP",
    lengthMeters: 2200,
    maxSpeedKmH: 120,
    status: "OCCUPIED",
    occupiedByTrainId: "P32",
    utilizationPercentage: 72,
    signalId: "S09",
    startCoord: { x: 820, y: 190 },
    endCoord: { x: 910, y: 190 }
  },
  {
    id: "B11",
    name: "Block 11 (Holambi Kalan Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1400,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 35,
    stationId: "ST_HOLAMBI",
    startCoord: { x: 910, y: 190 },
    endCoord: { x: 990, y: 190 }
  },
  {
    id: "B12",
    name: "Block 12 (Holambi Kalan - Narela)",
    trackType: "MAIN_UP",
    lengthMeters: 2400,
    maxSpeedKmH: 120,
    status: "CLEAR",
    utilizationPercentage: 58,
    signalId: "S10",
    startCoord: { x: 990, y: 190 },
    endCoord: { x: 1080, y: 190 }
  },
  {
    id: "B13",
    name: "Block 13 (Narela Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1500,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 50,
    stationId: "ST_NARELA",
    startCoord: { x: 1080, y: 190 },
    endCoord: { x: 1160, y: 190 }
  },
  {
    id: "B14",
    name: "Block 14 (Narela - Sonipat)",
    trackType: "MAIN_UP",
    lengthMeters: 3000,
    maxSpeedKmH: 130,
    status: "OCCUPIED",
    occupiedByTrainId: "E205",
    utilizationPercentage: 77,
    signalId: "S11",
    startCoord: { x: 1160, y: 190 },
    endCoord: { x: 1250, y: 190 }
  },
  {
    id: "B15",
    name: "Block 15 (Sonipat Station)",
    trackType: "MAIN_UP",
    lengthMeters: 1600,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 42,
    stationId: "ST_SONIPAT",
    signalId: "S12",
    startCoord: { x: 1250, y: 190 },
    endCoord: { x: 1340, y: 190 }
  },

  // MAIN DOWN TRACK (y: 250)
  {
    id: "B16",
    name: "Block 16 (Sonipat South)",
    trackType: "MAIN_DOWN",
    lengthMeters: 1800,
    maxSpeedKmH: 120,
    status: "CLEAR",
    utilizationPercentage: 40,
    startCoord: { x: 1340, y: 250 },
    endCoord: { x: 1250, y: 250 }
  },
  {
    id: "B17",
    name: "Block 17 (Sonipat - Narela South)",
    trackType: "MAIN_DOWN",
    lengthMeters: 2800,
    maxSpeedKmH: 120,
    status: "OCCUPIED",
    occupiedByTrainId: "P18",
    utilizationPercentage: 68,
    startCoord: { x: 1250, y: 250 },
    endCoord: { x: 1160, y: 250 }
  },
  {
    id: "B18",
    name: "Block 18 (Narela South)",
    trackType: "MAIN_DOWN",
    lengthMeters: 1400,
    maxSpeedKmH: 90,
    status: "CLEAR",
    utilizationPercentage: 30,
    startCoord: { x: 1160, y: 250 },
    endCoord: { x: 1080, y: 250 }
  },
  {
    id: "B19",
    name: "Block 19 (Narela - Holambi South)",
    trackType: "MAIN_DOWN",
    lengthMeters: 2400,
    maxSpeedKmH: 120,
    status: "CLEAR",
    utilizationPercentage: 45,
    startCoord: { x: 1080, y: 250 },
    endCoord: { x: 990, y: 250 }
  },
  {
    id: "B20",
    name: "Block 20 (Holambi - Badli South)",
    trackType: "MAIN_DOWN",
    lengthMeters: 2200,
    maxSpeedKmH: 110,
    status: "OCCUPIED",
    occupiedByTrainId: "F55",
    utilizationPercentage: 81,
    startCoord: { x: 990, y: 250 },
    endCoord: { x: 820, y: 250 }
  },

  // LOOP LINES & CROSSOVERS
  {
    id: "L01",
    name: "Subzi Mandi Loop 1",
    trackType: "LOOP",
    lengthMeters: 900,
    maxSpeedKmH: 45,
    status: "OCCUPIED",
    occupiedByTrainId: "F21",
    utilizationPercentage: 65,
    stationId: "ST_SUBZI_MANDI",
    startCoord: { x: 230, y: 150 },
    endCoord: { x: 310, y: 150 }
  },
  {
    id: "L02",
    name: "Adarsh Nagar Loop 1",
    trackType: "LOOP",
    lengthMeters: 1000,
    maxSpeedKmH: 45,
    status: "CLEAR",
    utilizationPercentage: 20,
    stationId: "ST_ADARSH_NAGAR",
    startCoord: { x: 570, y: 150 },
    endCoord: { x: 650, y: 150 }
  },
  {
    id: "L03",
    name: "Badli Loop 1",
    trackType: "LOOP",
    lengthMeters: 950,
    maxSpeedKmH: 45,
    status: "CLEAR",
    utilizationPercentage: 15,
    stationId: "ST_BADLI",
    startCoord: { x: 740, y: 150 },
    endCoord: { x: 820, y: 150 }
  },
  {
    id: "L04",
    name: "Narela Loop 1",
    trackType: "LOOP",
    lengthMeters: 1050,
    maxSpeedKmH: 45,
    status: "OCCUPIED",
    occupiedByTrainId: "F88",
    utilizationPercentage: 70,
    stationId: "ST_NARELA",
    startCoord: { x: 1080, y: 150 },
    endCoord: { x: 1160, y: 150 }
  },
  {
    id: "C01",
    name: "Adarsh Nagar Crossover 1",
    trackType: "CROSSOVER",
    lengthMeters: 400,
    maxSpeedKmH: 30,
    status: "CLEAR",
    utilizationPercentage: 10,
    startCoord: { x: 550, y: 190 },
    endCoord: { x: 590, y: 250 }
  }
];

export const SIGNALS: Signal[] = [
  {
    id: "S01",
    name: "Signal S01",
    aspect: "GREEN",
    blockId: "B01",
    nextBlockId: "B02",
    lastChanged: "10:40:12",
    controlledRoute: "R01_MAIN_UP",
    coord: { x: 145, y: 175 }
  },
  {
    id: "S02",
    name: "Signal S02",
    aspect: "GREEN",
    blockId: "B02",
    nextBlockId: "B03",
    lastChanged: "10:41:05",
    controlledRoute: "R02_MAIN_UP",
    coord: { x: 225, y: 175 }
  },
  {
    id: "S03",
    name: "Signal S03",
    aspect: "GREEN",
    blockId: "B03",
    nextBlockId: "B04",
    lastChanged: "10:39:50",
    controlledRoute: "R03_MAIN_UP",
    coord: { x: 305, y: 175 }
  },
  {
    id: "S04",
    name: "Signal S04",
    aspect: "YELLOW",
    blockId: "B04",
    nextBlockId: "B05",
    lastChanged: "10:41:40",
    controlledRoute: "R04_MAIN_UP",
    coord: { x: 395, y: 175 }
  },
  {
    id: "S05",
    name: "Signal S05",
    aspect: "RED",
    blockId: "B05",
    nextBlockId: "B06",
    lastChanged: "10:42:01",
    controlledRoute: "R05_MAIN_UP",
    coord: { x: 475, y: 175 }
  },
  {
    id: "S06",
    name: "Signal S06",
    aspect: "YELLOW",
    blockId: "B06",
    nextBlockId: "B07",
    lastChanged: "10:41:22",
    controlledRoute: "R06_MAIN_UP",
    coord: { x: 565, y: 175 }
  },
  {
    id: "S07",
    name: "Signal S07",
    aspect: "RED",
    blockId: "B07",
    nextBlockId: "B08",
    lastChanged: "10:42:10",
    controlledRoute: "R07_MAIN_UP",
    coord: { x: 645, y: 175 }
  },
  {
    id: "S08",
    name: "Signal S08",
    aspect: "GREEN",
    blockId: "B08",
    nextBlockId: "B09",
    lastChanged: "10:38:15",
    controlledRoute: "R08_MAIN_UP",
    coord: { x: 735, y: 175 }
  },
  {
    id: "S09",
    name: "Signal S09",
    aspect: "YELLOW",
    blockId: "B10",
    nextBlockId: "B11",
    lastChanged: "10:40:48",
    controlledRoute: "R09_MAIN_UP",
    coord: { x: 905, y: 175 }
  },
  {
    id: "S10",
    name: "Signal S10",
    aspect: "GREEN",
    blockId: "B12",
    nextBlockId: "B13",
    lastChanged: "10:39:10",
    controlledRoute: "R10_MAIN_UP",
    coord: { x: 1075, y: 175 }
  },
  {
    id: "S11",
    name: "Signal S11",
    aspect: "RED",
    blockId: "B14",
    nextBlockId: "B15",
    lastChanged: "10:41:55",
    controlledRoute: "R11_MAIN_UP",
    coord: { x: 1245, y: 175 }
  },
  {
    id: "S12",
    name: "Signal S12",
    aspect: "GREEN",
    blockId: "B15",
    nextBlockId: "YARD_SONIPAT",
    lastChanged: "10:35:00",
    controlledRoute: "R12_MAIN_UP",
    coord: { x: 1335, y: 175 }
  }
];
