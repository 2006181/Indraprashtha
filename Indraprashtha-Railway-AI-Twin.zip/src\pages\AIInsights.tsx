import React from "react";
import { useRailwayState } from "../hooks/useRailwayState";
import { Header } from "../components/layout/Header";
import { Sidebar, type NavTab } from "../components/layout/Sidebar";
import { MODEL_EVALUATIONS } from "../data/metrics";
import { BrainCircuit, Cpu, ArrowRight, ShieldCheck, Database, Zap, Activity } from "lucide-react";

interface AIInsightsProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  railwayState: ReturnType<typeof useRailwayState>;
}

export const AIInsights: React.FC<AIInsightsProps> = ({
  activeTab,
  onSelectTab,
  railwayState
}) => {
  const { conflicts, isDemoModeActive, setIsDemoModeActive, currentDemoStepIndex, resetState } = railwayState;

  const pipelineStages = [
    { name: "Telemetry Feed", status: "ONLINE", latency: "1.2s", icon: Database },
    { name: "Digital Twin State", status: "SYNCED", latency: "24 Ticks/s", icon: Activity },
    { name: "ETA & Propagation", status: "PREDICTING", latency: "84ms", icon: BrainCircuit },
    { name: "Conflict Detection", status: "ACTIVE", latency: "12ms", icon: Zap },
    { name: "MIP Optimization", status: "SOLVED", latency: "0.82s", icon: Cpu },
    { name: "Safety Validation", status: "VERIFIED", latency: "100% Pass", icon: ShieldCheck }
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-[#080c14] overflow-hidden text-slate-100 font-sans">
      <Header
        isDemoModeActive={isDemoModeActive}
        onToggleDemoMode={() => setIsDemoModeActive(!isDemoModeActive)}
        onResetState={resetState}
        activeConflictsCount={conflicts.length}
        currentDemoStepIndex={currentDemoStepIndex}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeTab={activeTab} onSelectTab={onSelectTab} />

        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-y-auto font-mono text-xs select-none">
          <div className="flex items-center justify-between p-3 rounded bg-slate-900 border border-slate-800">
            <div className="flex items-center space-x-3">
              <BrainCircuit className="w-5 h-5 text-cyan-400" />
              <div>
                <h2 className="font-bold text-slate-100 text-sm">AI MODEL EVALUATION & EXPLAINABILITY ENGINE</h2>
                <p className="text-slate-400">Machine Learning models powering ETA prediction, delay graph propagation, and conflict resolution</p>
              </div>
            </div>
            <div className="px-3 py-1 rounded bg-amber-950/60 border border-amber-800 text-amber-300 font-bold text-[11px]">
              DEMO / SIMULATION BENCHMARKS
            </div>
          </div>

          <div className="scada-panel p-4 space-y-3">
            <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-slate-800 pb-2">
              REAL-TIME AI PROCESSING PIPELINE
            </h3>

            <div className="grid grid-cols-6 gap-2 pt-2">
              {pipelineStages.map((stage, idx) => {
                const Icon = stage.icon;
                return (
                  <div key={idx} className="relative">
                    <div className="p-3 rounded bg-slate-900 border border-slate-800 flex flex-col items-center text-center space-y-1.5 hover:border-cyan-600 transition-colors">
                      <div className="w-8 h-8 rounded-full bg-cyan-950 border border-cyan-800 flex items-center justify-center">
                        <Icon className="w-4 h-4 text-cyan-400" />
                      </div>
                      <span className="font-bold text-slate-200 text-[11px] leading-tight">{stage.name}</span>
                      <span className="text-[10px] text-emerald-400 font-semibold">{stage.status}</span>
                      <span className="text-[9px] text-slate-500 font-mono">{stage.latency}</span>
                    </div>
                    {idx < 5 && (
                      <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 z-10">
                        <ArrowRight className="w-4 h-4 text-cyan-500/60" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {MODEL_EVALUATIONS.map((model, idx) => (
              <div key={idx} className="scada-panel p-4 space-y-3 border-l-4 border-l-cyan-500">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100 text-xs">{model.modelName}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-800">
                    {model.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center py-2">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 uppercase text-[10px] block">Mean Abs Error</span>
                    <span className="text-sm font-bold text-cyan-400">{model.mae}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 uppercase text-[10px] block">Confidence</span>
                    <span className="text-sm font-bold text-emerald-400">{model.confidence}</span>
                  </div>
                </div>

                <div className="space-y-1 text-[11px] border-t border-slate-800 pt-2">
                  <span className="text-slate-400 font-bold block uppercase text-[10px]">Key Input Features:</span>
                  <div className="flex flex-wrap gap-1">
                    {model.features.map((feat, fidx) => (
                      <span key={fidx} className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800 text-[10px]">
                        {feat}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
