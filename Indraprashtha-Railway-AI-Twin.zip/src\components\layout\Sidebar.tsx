import React, { useState } from "react";
import {
  LayoutDashboard,
  Network,
  TrainFront,
  FlaskConical,
  BrainCircuit,
  BarChart3,
  Activity,
  ChevronLeft,
  ChevronRight,
  Cpu
} from "lucide-react";

export type NavTab = "command" | "twin" | "traffic" | "scenarios" | "ai" | "analytics" | "health";

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  const navItems = [
    { id: "command", label: "Command Center", icon: LayoutDashboard },
    { id: "twin", label: "Digital Twin", icon: Network },
    { id: "traffic", label: "Traffic Monitor", icon: TrainFront },
    { id: "scenarios", label: "Scenario Simulator", icon: FlaskConical },
    { id: "ai", label: "AI Insights", icon: BrainCircuit },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "health", label: "System Health", icon: Activity }
  ];

  return (
    <aside
      className={`${
        isCollapsed ? "w-16" : "w-60"
      } bg-slate-950 border-r border-slate-800/80 transition-all duration-300 flex flex-col justify-between z-20 select-none shrink-0`}
    >
      {/* Top Navigation Links */}
      <div className="p-2.5">
        <div className="flex items-center justify-between px-3 py-2 mb-2">
          {!isCollapsed && <span className="text-[11px] font-mono uppercase text-slate-500 font-semibold tracking-wider">NAV MATRIX</span>}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors ml-auto"
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id as NavTab)}
                className={`w-full flex items-center ${
                  isCollapsed ? "justify-center px-0" : "px-3"
                } py-2.5 rounded-md text-xs font-medium transition-all ${
                  isActive
                    ? "bg-cyan-950/80 text-cyan-300 border border-cyan-700/50 shadow-inner font-semibold"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent"
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-cyan-400" : "text-slate-400"}`} />
                {!isCollapsed && <span className="ml-3 truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom System Subsystem Telemetry Status */}
      {!isCollapsed && (
        <div className="p-3 m-2.5 bg-slate-900/90 rounded border border-slate-800/80 space-y-2 text-[11px] font-mono">
          <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-1.5 font-bold">
            <span className="flex items-center space-x-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>SUBSYSTEMS</span>
            </span>
            <span className="text-[10px] text-emerald-400">100% OK</span>
          </div>

          <div className="space-y-1.5 text-slate-300">
            <div className="flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-slate-300">Digital Twin</span>
              </span>
              <span className="text-emerald-400 font-semibold">Online</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-slate-300">Simulation Engine</span>
              </span>
              <span className="text-emerald-400 font-semibold">Ready</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span className="text-slate-300">AI Engine</span>
              </span>
              <span className="text-cyan-400 font-semibold">93% Acc</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span className="text-slate-300">Safety Check</span>
              </span>
              <span className="text-purple-400 font-semibold">Active</span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
