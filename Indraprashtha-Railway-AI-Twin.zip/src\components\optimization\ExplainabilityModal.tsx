import React from "react";
import type { AIRecommendation } from "../../types/railway";
import { X, ShieldCheck, CheckCircle2, HelpCircle } from "lucide-react";

interface ExplainabilityModalProps {
  recommendation: AIRecommendation;
  onClose: () => void;
}

export const ExplainabilityModal: React.FC<ExplainabilityModalProps> = ({
  recommendation,
  onClose
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 font-mono text-xs select-none">
      <div className="bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="h-14 bg-slate-950 px-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="font-bold text-slate-100 uppercase tracking-wide text-sm">WHY THIS ACTION?</h3>
              <p className="text-[10px] text-slate-400">Explainable AI Decision Audit Trail • {recommendation.id}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Recommendation Overview */}
          <div className="p-3.5 rounded bg-slate-950 border border-cyan-800/60 space-y-1">
            <span className="text-[10px] text-cyan-400 font-bold uppercase">PROPOSED DISPATCH COMMAND</span>
            <p className="text-sm font-bold text-slate-100">{recommendation.actionTitle}</p>
            <p className="text-xs text-slate-400">
              Hold {recommendation.targetTrainId} for {recommendation.holdDurationMinutes} mins at {recommendation.holdLocation}
            </p>
          </div>

          {/* 5-Point Reason Breakdown */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-slate-800 pb-1">
              DECISION RATIONALE (5-POINT BREAKDOWN)
            </h4>
            <div className="space-y-2 text-slate-300">
              {recommendation.reasoning.map((reason, idx) => (
                <div key={idx} className="p-2.5 rounded bg-slate-950/80 border border-slate-800/80 flex items-start space-x-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-xs leading-relaxed text-slate-200">{reason}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Safety Validation Verification */}
          <div className="space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1">
              <h4 className="font-bold text-slate-200 uppercase tracking-wider text-xs flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>SAFETY ENGINE VALIDATIONS</span>
              </h4>
              <span className="text-emerald-400 font-bold text-[10px] bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                ✓ ALL PASSED
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2 text-xs">
              {recommendation.safetyValidations.map((check, idx) => (
                <div key={idx} className="p-2 rounded bg-slate-950 border border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-200">{check.name}</span>
                    <p className="text-[10px] text-slate-400">{check.details}</p>
                  </div>
                  <span className="text-emerald-400 font-bold text-[11px] flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>PASSED</span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">Model Confidence: <span className="text-cyan-400 font-bold">{recommendation.confidenceScore}%</span></span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700"
          >
            CLOSE AUDIT
          </button>
        </div>
      </div>
    </div>
  );
};
