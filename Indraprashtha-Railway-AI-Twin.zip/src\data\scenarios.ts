import type { Scenario, AIRecommendation, PresentationDemoStep, Conflict } from "../types/railway";

export const SAMPLE_CONFLICTS: Conflict[] = [
  {
    id: "CONF_01",
    type: "CROSSING_CONFLICT",
    severity: "HIGH",
    blockId: "B08",
    primaryTrainId: "E102",
    secondaryTrainId: "F21",
    etaSeconds: 272,
    description: "Freight F21 is occupying Block B07 with 8 min delay. High-speed Express E102 approaching Block B06 will experience forced braking at Signal S07 unless F21 is held at Subzi Mandi Loop L01.",
    impactMinutes: 12.4,
    timestamp: "10:42:15"
  },
  {
    id: "CONF_02",
    type: "HEADWAY_VIOLATION",
    severity: "MEDIUM",
    blockId: "B10",
    primaryTrainId: "P32",
    secondaryTrainId: "E108",
    etaSeconds: 540,
    description: "Minimum headway restriction (3.0 min) projected between Commuter P32 and Vande Bharat E108 at Holambi Kalan approach.",
    impactMinutes: 4.2,
    timestamp: "10:40:30"
  }
];

export const CURRENT_AI_RECOMMENDATION: AIRecommendation = {
  id: "REC_AI_102",
  actionTitle: "Hold Freight F21 at Loop L01 & Release Express E102",
  targetTrainId: "F21",
  holdLocation: "Subzi Mandi Loop L01 (Platform 3)",
  holdDurationMinutes: 3,
  releaseTrainId: "E102",
  releaseBlockId: "B08",
  expectedResults: {
    delayReductionPercent: 39.2,
    throughputIncreasePercent: 14.8,
    resolvedConflictsCount: 2,
    energySavedKwh: 480
  },
  reasoning: [
    "1. Kalka Shatabdi (E102) holds High-Priority passenger status over Container Freight (F21).",
    "2. F21 can safely switch to Subzi Mandi Loop L01 without violating platform capacity constraints.",
    "3. Block B08 will clear in approximately 2.4 minutes under clear-signal sequence.",
    "4. Holding F21 for 3 minutes prevents downstream cascade delays across Blocks B08–B12.",
    "5. Safety Engine verified 0 minimum-headway or signal overlap violations."
  ],
  safetyValidations: [
    { name: "Minimum Headway Constraint (>= 3.0 min)", passed: true, details: "Projected headway: 4.8 min (SAFE)" },
    { name: "Signal Overlap Margin Check", passed: true, details: "Overlap clear at S07 & S08" },
    { name: "Platform Capacity Verification", passed: true, details: "Subzi Mandi Platform 3 Loop available" },
    { name: "Braking Distance Safety Envelope", passed: true, details: "E102 stopping distance 1150m (Sufficient)" },
    { name: "Power Grid Load Headroom", passed: true, details: "Draw within 12.5 MW sector threshold" }
  ],
  confidenceScore: 91.4,
  timestamp: "10:42:18 IST"
};

export const WHAT_IF_SCENARIOS: Scenario[] = [
  {
    id: "SCN_01",
    title: "Freight Delay Disruption at Block B07",
    description: "Container Freight F21 suffers unexpected engine power loss, delaying it by 15 minutes near Subzi Mandi.",
    injectedTrainId: "F21",
    injectedDelayMinutes: 15,
    trafficDensity: "HIGH",
    strategies: [
      {
        id: "STRAT_A",
        name: "Strategy A: Hold Express E102",
        description: "Keep Express E102 behind Freight F21 on the main track.",
        avgDelayMinutes: 12.4,
        throughputPerHour: 7.8,
        conflictCount: 2,
        riskLevel: "HIGH",
        isAiRecommended: false,
        actions: ["Maintain current signal aspect RED at S07", "Wait for F21 to clear B08"],
        metrics: { delayReductionPercent: 0, throughputIncreasePercent: 0, resolvedConflictsCount: 0, energySavedKwh: 0 }
      },
      {
        id: "STRAT_B",
        name: "Strategy B: Hold Freight F21",
        description: "Divert F21 to Loop Line 1 and let E102 pass on Main Up line.",
        avgDelayMinutes: 7.1,
        throughputPerHour: 8.7,
        conflictCount: 1,
        riskLevel: "MEDIUM",
        isAiRecommended: false,
        actions: ["Switch point C01 to Loop L01", "Hold F21 for 5 mins"],
        metrics: { delayReductionPercent: 24, throughputIncreasePercent: 8, resolvedConflictsCount: 1, energySavedKwh: 210 }
      },
      {
        id: "STRAT_C",
        name: "Strategy C: Dynamic Loop Loop Routing (AI Recommended)",
        description: "Divert F21 to Loop L01 for 3 min, accelerate E102 to 110 km/h, and clear Block B08 in 2.4 min.",
        avgDelayMinutes: 5.1,
        throughputPerHour: 9.4,
        conflictCount: 0,
        riskLevel: "LOW",
        isAiRecommended: true,
        actions: ["Divert F21 to Loop L01 (3 mins)", "Green aspect on S07 for E102", "Adjust P32 speed to 65 km/h"],
        metrics: { delayReductionPercent: 39.2, throughputIncreasePercent: 14.8, resolvedConflictsCount: 2, energySavedKwh: 480 }
      }
    ]
  },
  {
    id: "SCN_02",
    title: "Track Maintenance Block at Block B12",
    description: "Emergency rail defect forces 45-minute closure of Block B12 between Holambi and Narela.",
    injectedBlockedBlockId: "B12",
    trafficDensity: "HIGH",
    strategies: [
      {
        id: "STRAT_M1",
        name: "Strategy A: Queue Trains on Approach",
        description: "Hold all northbound traffic at Badli and Holambi stations.",
        avgDelayMinutes: 18.2,
        throughputPerHour: 6.2,
        conflictCount: 4,
        riskLevel: "HIGH",
        isAiRecommended: false,
        actions: ["Stop E205 at B11", "Hold P32 at B10"],
        metrics: { delayReductionPercent: 0, throughputIncreasePercent: 0, resolvedConflictsCount: 0, energySavedKwh: 0 }
      },
      {
        id: "STRAT_M2",
        name: "Strategy B: Single-Line Bi-Directional Working (AI Recommended)",
        description: "Route northbound trains through Down Track B19 using Crossover C01 with automated headway protection.",
        avgDelayMinutes: 8.4,
        throughputPerHour: 8.5,
        conflictCount: 0,
        riskLevel: "LOW",
        isAiRecommended: true,
        actions: ["Activate Bi-Directional Signaling on B19", "Crossover E205 at Holambi", "Hold Freight F55 for 4 mins"],
        metrics: { delayReductionPercent: 53.8, throughputIncreasePercent: 37.1, resolvedConflictsCount: 4, energySavedKwh: 620 }
      }
    ]
  }
];

export const SIH_DEMO_STEPS: PresentationDemoStep[] = [
  {
    stepIndex: 1,
    title: "Step 1: Baseline Normal Section Operation",
    description: "The Delhi–North Corridor (Delhi Jn to Sonipat) is operating under standard automatic block signaling. Section throughput is 9.2 trains/hour.",
    timeString: "10:00:00 IST",
    highlightBlockId: "B01"
  },
  {
    stepIndex: 2,
    title: "Step 2: Freight Delay Injection (F21 Disruption)",
    description: "Container Freight F21 experiences a 10-minute delay at Block B07. Upstream traffic density starts increasing.",
    timeString: "10:05:00 IST",
    highlightTrainId: "F21",
    highlightBlockId: "B07"
  },
  {
    stepIndex: 3,
    title: "Step 3: Digital Twin & AI Bottleneck Prediction",
    description: "The Digital Twin detects potential crossing conflict between F21 and High-Priority Express E102 at Block B08 (ETA 4 min 32 sec).",
    timeString: "10:07:30 IST",
    highlightBlockId: "B08",
    highlightTrainId: "E102"
  },
  {
    stepIndex: 4,
    title: "Step 4: AI Strategy Generation & Safety Check",
    description: "AI Engine evaluates 24 feasible dispatching strategies. Strategy C (Dynamic Loop Diversion + Speed Tuning) clears all safety checks with 91.4% confidence.",
    timeString: "10:09:15 IST",
    highlightBlockId: "L01"
  },
  {
    stepIndex: 5,
    title: "Step 5: Controller Approval & Optimized Flow",
    description: "Controller approves AI recommendation: Hold F21 for 3 min at Subzi Mandi Loop L01. Result: Delay reduced by 39.2%, Throughput up by 14.8%, 0 Conflicts!",
    timeString: "10:11:00 IST",
    highlightTrainId: "E102"
  }
];
