import React from "react";
import type { MetricSummary } from "../../types/railway";
import { TrendingUp, TrendingDown, Train, AlertTriangle, ShieldCheck, Gauge } from "lucide-react";

interface KpiBarProps {
  metrics: MetricSummary;
  activeConflictsCount: number;
}

export const KpiBar: React.FC<KpiBarProps> = ({ metrics, activeConflictsCount }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 p-4 bg-slate-950 border-b border-slate-800/80">
      {/* 1. Section Throughput */}
      <div className="scada-panel p-3 flex flex-col justify-between relative overflow-hidden border-l-4 border-l-cyan-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono font-semibold uppercase">
          <span>SECTION THROUGHPUT</span>
          <Gauge className="w-4 h-4 text-cyan-400" />
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-bold font-mono text-slate-100">{metrics.throughputPerHour}</span>
            <span className="text-xs text-slate-400 font-mono ml-1.5">trains/hr</span>
          </div>
          <div className="flex items-center text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50">
            <TrendingUp className="w-3 h-3 mr-1" />
            <span>↑ {metrics.throughputTrendPercent}%</span>
          </div>
        </div>
      </div>

      {/* 2. Average Delay */}
      <div className="scada-panel p-3 flex flex-col justify-between relative overflow-hidden border-l-4 border-l-emerald-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono font-semibold uppercase">
          <span>AVERAGE DELAY</span>
          <span className="text-emerald-400 text-xs font-mono font-bold">IMPROVED</span>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-bold font-mono text-slate-100">{metrics.avgDelayMinutes}</span>
            <span className="text-xs text-slate-400 font-mono ml-1.5">min</span>
          </div>
          <div className="flex items-center text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50">
            <TrendingDown className="w-3 h-3 mr-1" />
            <span>↓ {Math.abs(metrics.delayTrendPercent)}%</span>
          </div>
        </div>
      </div>

      {/* 3. Active Trains */}
      <div className="scada-panel p-3 flex flex-col justify-between relative overflow-hidden border-l-4 border-l-blue-500">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono font-semibold uppercase">
          <span>ACTIVE TRAINS</span>
          <Train className="w-4 h-4 text-blue-400" />
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-bold font-mono text-slate-100">{metrics.activeTrainsCount}</span>
            <span className="text-xs text-slate-400 font-mono ml-1.5">units</span>
          </div>
          <span className="text-[11px] font-mono text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-800/50">
            MONITORED
          </span>
        </div>
      </div>

      {/* 4. Active Conflicts */}
      <div
        className={`scada-panel p-3 flex flex-col justify-between relative overflow-hidden border-l-4 ${
          activeConflictsCount > 0 ? "border-l-rose-500 bg-rose-950/10" : "border-l-emerald-500"
        }`}
      >
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono font-semibold uppercase">
          <span>ACTIVE CONFLICTS</span>
          {activeConflictsCount > 0 ? (
            <AlertTriangle className="w-4 h-4 text-rose-400 animate-pulse" />
          ) : (
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          )}
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className={`text-2xl font-bold font-mono ${activeConflictsCount > 0 ? "text-rose-400" : "text-slate-100"}`}>
              {activeConflictsCount}
            </span>
          </div>
          <span
            className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
              activeConflictsCount > 0
                ? "bg-rose-950/80 text-rose-400 border-rose-800/60 animate-pulse"
                : "bg-emerald-950/60 text-emerald-400 border-emerald-800/50"
            }`}
          >
            {activeConflictsCount > 0 ? "WARNING" : "SAFE / CLEAR"}
          </span>
        </div>
      </div>

      {/* 5. Section Utilization */}
      <div className="scada-panel p-3 flex flex-col justify-between relative overflow-hidden border-l-4 border-l-purple-500 col-span-2 md:col-span-1">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono font-semibold uppercase">
          <span>SECTION UTILIZATION</span>
          <span className="text-purple-400 text-xs font-mono font-bold">OPTIMAL</span>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-bold font-mono text-slate-100">{metrics.sectionUtilizationPercent}%</span>
          </div>
          <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-purple-500 h-full rounded-full" style={{ width: `${metrics.sectionUtilizationPercent}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
};
