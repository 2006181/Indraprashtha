import { useState, useEffect } from "react";

export function useWebSocket() {
  const [isConnected] = useState<boolean>(true);
  const [tickRate, setTickRate] = useState<number>(24);
  const [latencyMs, setLatencyMs] = useState<number>(84);
  const [lastUpdated, setLastUpdated] = useState<string>("Just now");

  useEffect(() => {
    const interval = setInterval(() => {
      setLatencyMs(80 + Math.floor(Math.random() * 12));
      setTickRate(23 + Math.floor(Math.random() * 3));
      setLastUpdated(new Date().toLocaleTimeString("en-IN", { hour12: false }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return {
    isConnected,
    tickRate,
    latencyMs,
    lastUpdated
  };
}
