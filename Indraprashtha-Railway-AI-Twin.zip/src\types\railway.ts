export type TrainType = "EXPRESS" | "PASSENGER" | "FREIGHT" | "MAINTENANCE";
export type TrainDirection = "UP" | "DOWN";
export type TrainPriority = "HIGH" | "NORMAL" | "LOW";
export type TrainStatus = "ON_TIME" | "DELAYED" | "HOLD" | "CRITICAL";

export interface Train {
  id: string;
  name: string;
  number: string;
  type: TrainType;
  direction: TrainDirection;
  currentBlock: string;
  nextBlock: string;
  origin: string;
  destination: string;
  speed: number;          // in km/h
  targetSpeed: number;    // in km/h
  maxSpeed: number;       // in km/h
  scheduledEta: string;   // HH:MM
  predictedEta: string;   // HH:MM
  delayMinutes: number;   // minutes delayed (+ or -)
  priority: TrainPriority;
  status: TrainStatus;
  driverName?: string;
  lengthMeters: number;
  weightTons: number;
  routeProgress: number;  // 0 to 100 percentage along entire section
  coordinates?: { x: number; y: number };
}

export type BlockStatus = "CLEAR" | "OCCUPIED" | "RESTRICTED" | "BLOCKED";

export interface Block {
  id: string;
  name: string;
  trackType: "MAIN_UP" | "MAIN_DOWN" | "LOOP" | "CROSSOVER";
  lengthMeters: number;
  maxSpeedKmH: number;
  status: BlockStatus;
  occupiedByTrainId?: string;
  utilizationPercentage: number;
  signalId?: string;
  stationId?: string;
  startCoord: { x: number; y: number };
  endCoord: { x: number; y: number };
}

export type SignalAspect = "GREEN" | "YELLOW" | "RED";

export interface Signal {
  id: string;
  name: string;
  aspect: SignalAspect;
  blockId: string;
  nextBlockId: string;
  lastChanged: string;
  controlledRoute: string;
  coord: { x: number; y: number };
}

export interface Platform {
  number: number;
  status: "CLEAR" | "OCCUPIED" | "RESERVED" | "MAINTENANCE";
  occupiedByTrainId?: string;
  lineType: "MAIN" | "LOOP";
}

export interface Station {
  id: string;
  code: string;
  name: string;
  mileageKm: number;
  platforms: Platform[];
  coord: { x: number; y: number };
  incomingTrainCount: number;
  outgoingTrainCount: number;
}

export type ConflictSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export type ConflictType = "CROSSING_CONFLICT" | "HEADWAY_VIOLATION" | "PLATFORM_OVERBOOKING" | "MAINTENANCE_BLOCK";

export interface Conflict {
  id: string;
  type: ConflictType;
  severity: ConflictSeverity;
  blockId: string;
  primaryTrainId: string;
  secondaryTrainId?: string;
  etaSeconds: number;
  description: string;
  impactMinutes: number;
  timestamp: string;
}

export interface OptimizationResult {
  delayReductionPercent: number;
  throughputIncreasePercent: number;
  resolvedConflictsCount: number;
  energySavedKwh: number;
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  avgDelayMinutes: number;
  throughputPerHour: number;
  conflictCount: number;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  isAiRecommended?: boolean;
  actions: string[];
  metrics: OptimizationResult;
}

export interface SafetyValidationCheck {
  name: string;
  passed: boolean;
  details: string;
}

export interface AIRecommendation {
  id: string;
  actionTitle: string;
  targetTrainId: string;
  holdLocation: string;
  holdDurationMinutes: number;
  releaseTrainId: string;
  releaseBlockId: string;
  expectedResults: OptimizationResult;
  reasoning: string[];
  safetyValidations: SafetyValidationCheck[];
  confidenceScore: number;
  timestamp: string;
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  injectedTrainId?: string;
  injectedDelayMinutes?: number;
  injectedBlockedBlockId?: string;
  priorityOverride?: TrainPriority;
  trafficDensity: "NORMAL" | "HIGH" | "PEAK";
  strategies: Strategy[];
}

export interface MetricSummary {
  throughputPerHour: number;
  throughputTrendPercent: number;
  avgDelayMinutes: number;
  delayTrendPercent: number;
  activeTrainsCount: number;
  activeConflictsCount: number;
  sectionUtilizationPercent: number;
  safetyScore: number;
}

export interface SubsystemHealth {
  digitalTwin: "HEALTHY" | "DEGRADED" | "OFFLINE";
  simulationEngine: "HEALTHY" | "DEGRADED" | "OFFLINE";
  mlEngine: "HEALTHY" | "DEGRADED" | "OFFLINE";
  optimizationEngine: "HEALTHY" | "DEGRADED" | "OFFLINE";
  safetyEngine: "HEALTHY" | "DEGRADED" | "OFFLINE";
  tickRatePerSec: number;
  latencyMs: number;
  optimizationTimeSec: number;
  activeWebSocketCount: number;
  dataFreshnessSec: number;
}

export interface PresentationDemoStep {
  stepIndex: number;
  title: string;
  description: string;
  timeString: string;
  highlightBlockId?: string;
  highlightTrainId?: string;
}
